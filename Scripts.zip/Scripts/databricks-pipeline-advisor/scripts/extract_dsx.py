#!/usr/bin/env python3
"""
extract_dsx.py — DataStage DSX XML to compact JSON profile extractor.

Converts a DSX/XML export file into a compact JSON profile containing
only the gap-relevant data needed by the databricks-pipeline-advisor.
Reduces token consumption ~50-100x vs pasting raw XML into the agent.

Usage:
    python scripts/extract_dsx.py <dsx_file> [OPTIONS]

Options:
    --jobs JOB1,JOB2    Only extract specified job names (comma-separated)
    --force             Re-extract even if profile is newer than DSX
    --out PATH          Write profile to this path (default: <dsx_stem>_profile.json)
    --list-jobs         List all job names in the DSX and exit

Output:
    <dsx_stem>_profile.json in the same folder as the DSX file (or --out path).
    Stdout: one-line summary per job extracted.

Exit codes: 0=success, 1=parse error, 2=file not found
"""

import argparse
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional, Tuple


# --- SqlType -> cast string map --------------------------------------------------

def _cast(sql_type: int, precision: int, scale: int) -> Optional[str]:
    if sql_type == 3:
        return f"decimal({precision},{scale})"
    if sql_type == 4:
        return "int"
    if sql_type == 5:
        return "smallint"
    if sql_type == -5:
        return "bigint"
    if sql_type == 9:
        return "date"
    if sql_type == 11:
        return "timestamp"
    if sql_type == 92:
        return "time_hms"  # sentinel -> D-TERA-CAST emits F.date_format(..., "HH:mm:ss")
    return None  # VARCHAR/CHAR and others — no cast needed


# ─── XML helpers ─────────────────────────────────────────────────────────────

def get_prop(element: ET.Element, name: str) -> Optional[str]:
    """Return text of <Property Name="{name}"> direct child, or None."""
    for child in element:
        if child.tag == "Property" and child.get("Name") == name:
            return (child.text or "").strip()
    return None


def get_custom_prop(element: ET.Element, name: str) -> Optional[str]:
    """Read from <Collection Name="Properties" Type="CustomProperty">."""
    for coll in element:
        if coll.tag == "Collection" and coll.get("Name") == "Properties":
            for sub in coll:
                if sub.tag == "SubRecord":
                    if get_prop(sub, "Name") == name:
                        return get_prop(sub, "Value")
    return None


def get_metabag_prop(element: ET.Element, name: str) -> Optional[str]:
    """Read from <Collection Name="MetaBag" Type="MetaProperty">."""
    for coll in element:
        if coll.tag == "Collection" and coll.get("Name") == "MetaBag":
            for sub in coll:
                if sub.tag == "SubRecord":
                    if get_prop(sub, "Name") == name:
                        return get_prop(sub, "Value")
    return None


def split_pins(pins_str: str) -> List[str]:
    """Split a pipe-separated pin identifier string into a list."""
    return [p.strip() for p in (pins_str or "").split("|") if p.strip()]


# ─── DataStage list property decoder ─────────────────────────────────────────

def decode_list_prop(raw: str, key: str) -> List[str]:
    r"""
    Decode DataStage escape-encoded list property.
    Format: \(2)\(2)0\(1)\(3){key}\(2){value}\(2)0\(1)\(3){key}\(2){value}...
    """
    if not raw:
        return []
    raw = (raw or "").strip()
    if raw == r"\(20)" or not raw:
        return []
    sep = f"\\(1)\\(3){key}\\(2)"
    parts = raw.split(sep)
    if len(parts) <= 1:
        # Fallback for properties stored differently
        sep2 = f"\\(3){key}\\(2)"
        parts = raw.split(sep2)
    result = []
    for part in parts[1:]:  # skip header
        col = part.split("\\(2)")[0].strip()
        if col and col != "\\(20)":
            result.append(col)
    return result


# ─── XMLProperties embedded-XML parser ───────────────────────────────────────

def parse_xml_props(raw_value: str) -> Optional[ET.Element]:
    """
    The XMLProperties value is already entity-decoded by the outer ET parser.
    Parse it as a standalone XML document.
    Strips the <?xml ...?> processing instruction which can cause issues.
    """
    if not raw_value:
        return None
    text = raw_value.strip()
    # Remove XML declaration — encoding='UTF-16' is misleading for an in-memory string
    text = re.sub(r"<\?xml[^?]*\?>", "", text, count=1).strip()
    try:
        return ET.fromstring(text)
    except ET.ParseError:
        return None


def xp_text(xp: Optional[ET.Element], *path: str) -> str:
    """Walk element path, return text of last element or empty string."""
    if xp is None:
        return ""
    cur = xp
    for tag in path:
        cur = cur.find(tag)
        if cur is None:
            return ""
    return (cur.text or "").strip()


# ─── Column schema extraction (type_cast_map) ────────────────────────────────

def extract_output_columns(record: ET.Element) -> Dict[str, str]:
    """
    Build type_cast_map from <Collection Name="Columns" Type="OutputColumn">.
    Returns {col_name: cast_string} for castable SqlTypes only.
    """
    cast_map: Dict[str, str] = {}
    for coll in record:
        if coll.tag != "Collection" or coll.get("Name") != "Columns":
            continue
        for sub in coll:
            if sub.tag != "SubRecord":
                continue
            col_name = get_prop(sub, "Name")
            sql_type_str = get_prop(sub, "SqlType")
            if not col_name or not sql_type_str:
                continue
            try:
                sql_type = int(sql_type_str)
                precision = int(get_prop(sub, "Precision") or "0")
                scale = int(get_prop(sub, "Scale") or "0")
            except ValueError:
                continue
            cast_str = _cast(sql_type, precision, scale)
            if cast_str is not None:
                cast_map[col_name] = cast_str
    return cast_map


def build_type_cast_map(
    stage: ET.Element,
    record_map: Dict[str, ET.Element],
) -> Dict[str, str]:
    """
    For a target TeradataConnectorPX stage, build type_cast_map by following
    the upstream Partner link from each input pin to the upstream output pin's
    OutputColumn collection. This gives us the actual data types flowing into
    the Teradata target.

    Path: stage.InputPins -> CustomInput record -> Partner -> upstream output pin -> OutputColumn
    """
    cast_map: Dict[str, str] = {}
    for pin_id in split_pins(get_prop(stage, "InputPins") or ""):
        input_pin = record_map.get(pin_id)
        if input_pin is None:
            continue
        partner_str = get_prop(input_pin, "Partner") or ""
        if not partner_str:
            continue
        # Partner format: "StageIdentifier|PinIdentifier" — take the PinIdentifier
        upstream_pin_id = partner_str.split("|")[-1].strip()
        upstream_pin = record_map.get(upstream_pin_id)
        if upstream_pin is None:
            continue
        cast_map.update(extract_output_columns(upstream_pin))
    return cast_map


# ─── SET clause parser ────────────────────────────────────────────────────────

def classify_set_value(value: str) -> Dict[str, str]:
    """Classify a SET RHS value and return {value, value_type, pyspark}."""
    v = value.strip()
    if v.upper().startswith("ORCHESTRATE."):
        col = v[len("ORCHESTRATE."):]
        return {"value": v, "value_type": "col_ref", "pyspark": f'F.col("s.{col}")'}
    if v.startswith("'") and v.endswith("'") and len(v) >= 2:
        inner = v[1:-1]
        return {"value": v, "value_type": "literal_string", "pyspark": f'F.lit("{inner}")'}
    try:
        int(v)
        return {"value": v, "value_type": "literal_number", "pyspark": f"F.lit({v})"}
    except ValueError:
        pass
    try:
        float(v)
        return {"value": v, "value_type": "literal_number", "pyspark": f"F.lit({v})"}
    except ValueError:
        pass
    # SQL expression: CASE WHEN, CURRENT_TIMESTAMP, CAST(...), etc.
    expr = re.sub(r"\bORCHESTRATE\.(\w+)", r"s.\1", v)
    return {"value": v, "value_type": "sql_expr", "pyspark": f'F.expr("{expr}")'}


def parse_set_clause(sql: str) -> List[Dict[str, str]]:
    """
    Extract SET col=value pairs from UPDATE SQL.
    Handles CASE WHEN expressions and nested parentheses.
    """
    m = re.search(r"\bSET\b(.*?)(?:\bWHERE\b|$)", sql, re.DOTALL | re.IGNORECASE)
    if not m:
        return []
    set_block = m.group(1).strip()

    # Split on commas at depth 0 only
    assignments: List[str] = []
    depth = 0
    current: List[str] = []
    for ch in set_block:
        if ch == "(":
            depth += 1
            current.append(ch)
        elif ch == ")":
            depth -= 1
            current.append(ch)
        elif ch == "," and depth == 0:
            assignments.append("".join(current).strip())
            current = []
        else:
            current.append(ch)
    if current:
        assignments.append("".join(current).strip())

    result = []
    for assignment in assignments:
        assignment = assignment.strip()
        if "=" not in assignment:
            continue
        eq_pos = assignment.index("=")
        col = assignment[:eq_pos].strip()
        value = assignment[eq_pos + 1:].strip()
        if col and value:
            entry: Dict[str, str] = {"col": col}
            entry.update(classify_set_value(value))
            result.append(entry)
    return result


# ─── WHERE clause parser ──────────────────────────────────────────────────────

def parse_where_clause(where_text: str) -> Tuple[List[str], List[str]]:
    """
    Split WHERE clause into join_keys and filter_conditions.

    - `col = ORCHESTRATE.col` -> join condition -> append col to join_keys
    - anything else -> target filter -> append rendered `t.col = ...` string

    Returns (join_keys, filter_conditions).
    """
    text = where_text.strip().lstrip("(").rstrip(")")

    # Split on AND at depth 0
    conditions: List[str] = []
    depth = 0
    current: List[str] = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == "(":
            depth += 1
            current.append(ch)
        elif ch == ")":
            depth -= 1
            current.append(ch)
        elif depth == 0 and text[i : i + 4].upper() == " AND":
            conditions.append("".join(current).strip())
            current = []
            i += 4
            continue
        else:
            current.append(ch)
        i += 1
    if current:
        conditions.append("".join(current).strip())

    join_keys: List[str] = []
    filter_conds: List[str] = []

    for cond in conditions:
        cond = cond.strip()
        m = re.match(r"^(\w+)\s*=\s*ORCHESTRATE\.(\w+)$", cond, re.IGNORECASE)
        if m:
            join_keys.append(m.group(1))
        else:
            # Prefix left-hand column with t.
            rendered = re.sub(r"^(\w+)\s*=", r"t.\1 =", cond)
            filter_conds.append(rendered)

    return join_keys, filter_conds


def extract_where_keys(where_text: str) -> List[str]:
    """Extract all col names from equality conditions in a WHERE clause (for DELETE)."""
    text = where_text.strip().lstrip("(").rstrip(")")
    keys = []
    for part in re.split(r"\s+AND\s+", text, flags=re.IGNORECASE):
        part = part.strip().lstrip("(").rstrip(")")
        m = re.match(r"^(\w+)\s*=", part)
        if m:
            keys.append(m.group(1))
    return keys


# ─── Per-stage extractors ─────────────────────────────────────────────────────

def _decode_first(raw: str, key: str) -> str:
    """Decode a single-value list property and return the first value."""
    vals = decode_list_prop(raw, key)
    return vals[0] if vals else ""


def _ext_cdc(stage: ET.Element) -> Dict:
    raw_key = get_custom_prop(stage, "key") or ""
    raw_drop = get_custom_prop(stage, "dropvalue") or ""
    raw_sel = get_custom_prop(stage, "selection") or ""
    return {
        "stage_type": "PxChangeCapture",
        "key_columns": decode_list_prop(raw_key, "key"),
        "exempt_columns": decode_list_prop(raw_drop, "dropvalue"),
        "selection": _decode_first(raw_sel, "selection") or raw_sel,
    }


def _ext_aggregator(stage: ET.Element) -> Dict:
    raw_key = get_custom_prop(stage, "groupKey") or ""
    return {
        "stage_type": "PxAggregator",
        "group_key_columns": decode_list_prop(raw_key, "groupKey"),
        # aggregate_expressions extracted from output pin columns by the advisor
    }


def _ext_transformer(
    stage: ET.Element,
    record_map: Dict[str, ET.Element],
) -> Dict:
    out_pins = split_pins(get_prop(stage, "OutputPins") or "")
    derivations = []
    output_constraints = []

    for pin_id in out_pins:
        pin_rec = record_map.get(pin_id)
        if pin_rec is None:
            continue
        pin_name = get_prop(pin_rec, "Name") or pin_id
        constraint = get_prop(pin_rec, "Constraint") or ""
        reject = get_prop(pin_rec, "Reject") or "0"
        if constraint:
            output_constraints.append(
                {
                    "output_name": pin_name,
                    "constraint": constraint,
                    "reject": reject == "1",
                }
            )
        for coll in pin_rec:
            if coll.tag != "Collection" or coll.get("Name") != "Columns":
                continue
            for sub in coll:
                if sub.tag != "SubRecord":
                    continue
                col = get_prop(sub, "Name")
                deriv = get_prop(sub, "ParsedDerivation") or get_prop(sub, "Derivation") or ""
                deriv = deriv.lstrip("\\(20)").strip()
                # Skip simple passthroughs (LinkName.ColumnName)
                if deriv and not re.match(r"^\w+\.\w+$", deriv):
                    derivations.append(
                        {"col": col, "derivation": deriv, "output_pin": pin_name}
                    )

    stage_vars = []
    for coll in stage:
        if coll.tag != "Collection" or coll.get("Name") != "StageVars":
            continue
        for sub in coll:
            if sub.tag != "SubRecord":
                continue
            var_name = get_prop(sub, "Name")
            expr = get_prop(sub, "ParsedExpression") or get_prop(sub, "Expression") or ""
            expr = expr.lstrip("\\(20)").strip()
            initial = get_prop(sub, "InitialValue")
            if var_name:
                stage_vars.append(
                    {
                        "var_name": var_name,
                        "expression": expr,
                        "stateful": initial is not None,
                        "initial_value": initial,
                    }
                )

    return {
        "stage_type": "TransformerStage",
        "non_trivial_derivations": derivations,
        "output_constraints": output_constraints,
        "stage_vars": stage_vars,
    }


def _ext_filter(stage: ET.Element, record_map: Dict[str, ET.Element]) -> Dict:
    # PxFilter stores per-output-pin conditions in Properties 'where' key.
    # Format: list-encoded, each entry = one condition for one output pin.
    raw_where = get_custom_prop(stage, "where") or ""
    conditions = decode_list_prop(raw_where, "where")
    # Also check output pin Constraint (some older exports use that)
    if not conditions:
        for pin_id in split_pins(get_prop(stage, "OutputPins") or ""):
            pin_rec = record_map.get(pin_id)
            if pin_rec is not None:
                c = get_prop(pin_rec, "Constraint") or ""
                if c:
                    conditions.append(c)
    return {"stage_type": "PxFilter", "conditions": conditions}


def _ext_lookup(stage: ET.Element, record_map: Dict[str, ET.Element]) -> Dict:
    lookup_fail = "fail"
    for pin_id in split_pins(get_prop(stage, "InputPins") or ""):
        pin_rec = record_map.get(pin_id)
        if pin_rec is None:
            continue
        if (get_prop(pin_rec, "LinkType") or "") == "2":  # reference pin
            lookup_fail = get_prop(pin_rec, "LookupFail") or "fail"
    return {"stage_type": "PxLookup", "lookup_fail": lookup_fail}


_JOIN_OPERATOR_MAP = {
    "innerjoin": "inner",
    "leftjoin": "left outer",
    "rightjoin": "right outer",
    "fulljoin": "full outer",
    "inner": "inner",
    "left": "left outer",
    "right": "right outer",
    "full": "full outer",
}


def _ext_join(stage: ET.Element) -> Dict:
    raw_key = get_custom_prop(stage, "key") or ""
    # PxJoin stores join type in Properties 'operator' key (e.g. 'innerjoin')
    # MetaBag 'join_type' is a fallback for older exports
    operator = get_custom_prop(stage, "operator") or get_metabag_prop(stage, "join_type") or "innerjoin"
    join_type = _JOIN_OPERATOR_MAP.get(operator.lower(), "inner")
    return {
        "stage_type": "PxJoin",
        "join_type": join_type,
        "key_columns": decode_list_prop(raw_key, "key"),
    }


def _decode_sort_keys(raw: str) -> List[Dict[str, str]]:
    r"""
    Decode DataStage sort key list property.
    Each entry format (after list-sep): COLUMN_NAME\(2)D\(2)0 or COLUMN_NAME\(2)A\(2)0
    Direction: A=ascending (default), D=descending.
    """
    if not raw or raw.strip() == r"\(20)":
        return []
    sep = r"\(1)\(3)sortKey\(2)"
    parts = raw.split(sep)
    result = []
    for part in parts[1:]:
        fields = part.split("\\(2)")
        col_name = fields[0].strip() if fields else ""
        direction_raw = fields[1].strip().upper() if len(fields) > 1 else "A"
        direction = "desc" if direction_raw == "D" else "asc"
        if col_name and col_name != "\\(20)":
            result.append({"col": col_name, "dir": direction})
    return result


def _ext_sort(stage: ET.Element) -> Dict:
    raw_key = get_custom_prop(stage, "sortKey") or ""
    return {"stage_type": "PxSort", "sort_keys": _decode_sort_keys(raw_key)}


def _ext_funnel(stage: ET.Element) -> Dict:
    count = len(split_pins(get_prop(stage, "InputPins") or ""))
    return {"stage_type": "PxFunnel", "input_pin_count": count}


def _ext_copy(stage: ET.Element) -> Dict:
    count = len(split_pins(get_prop(stage, "OutputPins") or ""))
    return {"stage_type": "PxCopy", "output_pin_count": count}


def _ext_switch(stage: ET.Element, record_map: Dict[str, ET.Element]) -> Dict:
    conditions = []
    for pin_id in split_pins(get_prop(stage, "OutputPins") or ""):
        pin_rec = record_map.get(pin_id)
        if pin_rec is None:
            continue
        conditions.append(
            {
                "output_name": get_prop(pin_rec, "Name") or pin_id,
                "condition": get_prop(pin_rec, "Constraint") or "",
            }
        )
    return {"stage_type": "PxSwitch", "output_conditions": conditions}


def _ext_merge(stage: ET.Element) -> Dict:
    raw_key = get_custom_prop(stage, "key") or ""
    return {
        "stage_type": "PxMerge",
        "key_columns": decode_list_prop(raw_key, "key"),
    }


def _ext_difference(stage: ET.Element) -> Dict:
    raw_key = get_custom_prop(stage, "key") or ""
    return {
        "stage_type": "PxDifference",
        "key_columns": decode_list_prop(raw_key, "key"),
    }


def _ext_modify(stage: ET.Element, record_map: Dict[str, ET.Element]) -> Dict:
    col_spec = []
    for pin_id in split_pins(get_prop(stage, "OutputPins") or ""):
        pin_rec = record_map.get(pin_id)
        if pin_rec is None:
            continue
        for coll in pin_rec:
            if coll.tag != "Collection" or coll.get("Name") != "Columns":
                continue
            for sub in coll:
                if sub.tag != "SubRecord":
                    continue
                col_spec.append(
                    {
                        "output_col": get_prop(sub, "Name") or "",
                        "source": get_prop(sub, "Derivation") or "",
                    }
                )
    return {"stage_type": "PxModify", "column_spec": col_spec}


def _ext_remdup(stage: ET.Element) -> Dict:
    raw_key = get_custom_prop(stage, "key") or ""
    return {
        "stage_type": "PxRemDup",
        "key_columns": decode_list_prop(raw_key, "key"),
    }


def _ext_surrogate(stage: ET.Element, record_map: Dict[str, ET.Element]) -> Dict:
    key_col = None
    for pin_id in split_pins(get_prop(stage, "OutputPins") or ""):
        pin_rec = record_map.get(pin_id)
        if pin_rec is None:
            continue
        for coll in pin_rec:
            if coll.tag != "Collection" or coll.get("Name") != "Columns":
                continue
            for sub in coll:
                if sub.tag != "SubRecord":
                    continue
                kp = get_prop(sub, "KeyPosition") or "0"
                try:
                    if int(kp) > 0:
                        key_col = get_prop(sub, "Name")
                except ValueError:
                    pass
    return {
        "stage_type": "PxSurrogateKeyGenerator",
        "key_column": key_col,
        "start_value": get_metabag_prop(stage, "start_value") or "1",
        "increment": get_metabag_prop(stage, "increment") or "1",
    }


def _ext_sequential_file(
    stage: ET.Element,
    record_map: Dict[str, ET.Element],
) -> Dict:
    """
    PxSequentialFile context and file path.

    Context: inferred from pin direction -- OutputPins only -> source (reading);
    InputPins only -> target (writing); both present -> check Properties 'Context'.

    File path: stored on the pin record's Properties collection under key 'file',
    as a list-encoded value.
    """
    in_pins = split_pins(get_prop(stage, "InputPins") or "")
    out_pins = split_pins(get_prop(stage, "OutputPins") or "")

    if in_pins and not out_pins:
        context_str = "target"
        pin_ids = in_pins
    elif out_pins and not in_pins:
        context_str = "source"
        pin_ids = out_pins
    else:
        # Both present — check Properties collection
        ctx_raw = get_custom_prop(stage, "Context") or ""
        context_str = _decode_first(ctx_raw, "Context").lower() or ("target" if in_pins else "source")
        pin_ids = in_pins or out_pins

    file_path = ""
    for pin_id in pin_ids:
        pin_rec = record_map.get(pin_id)
        if pin_rec is None:
            continue
        raw_file = get_custom_prop(pin_rec, "file") or ""
        file_path = _decode_first(raw_file, "file")
        if file_path:
            break

    file_suffix = os.path.splitext(os.path.basename(file_path))[0] if file_path else ""
    return {
        "stage_type": "PxSequentialFile",
        "context": context_str,
        "file_path": file_path,
        "file_suffix": file_suffix,
    }


def _ext_peek_rowgen_tail(stage: ET.Element, stage_type: str) -> Dict:
    tail_n = None
    if stage_type == "PxTail":
        tail_n = (
            get_metabag_prop(stage, "tail_count")
            or get_custom_prop(stage, "TailCount")
        )
    return {"stage_type": stage_type, "tail_n": tail_n}


def _ext_teradata(
    stage: ET.Element,
    record_map: Dict[str, ET.Element],
    job_source_tables: List[str],
) -> Dict:
    """
    Two-pass TeradataConnectorPX extraction.

    Step 1 (outer XML): context, reject_mappings, type_cast_map via upstream Partner link
    Step 2 (XMLProperties embedded XML): write_mode, table_reference, SQL data
    """
    # ── Step 1 ────────────────────────────────────────────────────────────────
    context = (get_custom_prop(stage, "Context") or "source").lower()
    reject_mappings = get_metabag_prop(stage, "MappingRejectAdd") or ""

    type_cast_map: Dict[str, str] = {}
    if context == "target":
        type_cast_map = build_type_cast_map(stage, record_map)

    # ── Step 2 ────────────────────────────────────────────────────────────────
    xml_props_raw = get_custom_prop(stage, "XMLProperties") or ""
    xp = parse_xml_props(xml_props_raw) if xml_props_raw else None

    write_mode = 0
    table_reference = ""
    insert_columns: List[str] = []
    update_statement = ""
    update_set_columns: List[Dict] = []
    update_join_keys: List[str] = []
    update_filter_conditions: List[str] = []
    upsert_key_columns: List[str] = []
    delete_statement = ""
    delete_key_columns: List[str] = []
    is_markback = False

    if xp is not None:
        usage = xp.find("Usage")

        # WriteMode
        wm = xp_text(xp, "Usage", "WriteMode") or "0"
        try:
            write_mode = int(wm)
        except ValueError:
            write_mode = 0

        # Table reference — try multiple locations
        table_reference = xp_text(xp, "Usage", "TableName")
        if not table_reference and usage is not None:
            sql_elem = usage.find("SQL")
            if sql_elem is not None:
                # For UPDATE/DELETE: table is in UpdateStatement/Tables/Table
                for stmt_tag in ("UpdateStatement", "DeleteStatement"):
                    stmt = sql_elem.find(stmt_tag)
                    if stmt is not None:
                        tables = stmt.find("Tables")
                        if tables is not None:
                            for t in tables.findall("Table"):
                                v = (t.text or "").strip()
                                if v:
                                    table_reference = v
                                    break
                        if table_reference:
                            break
                # For SOURCE stages: table is embedded in SelectStatement FROM clause
                if not table_reference and context == "source":
                    sel_stmt = sql_elem.find("SelectStatement")
                    if sel_stmt is not None:
                        select_sql = (sel_stmt.text or "").strip()
                        m_from = re.search(r"\bFROM\b\s+(\S+)", select_sql, re.IGNORECASE)
                        if m_from:
                            table_reference = m_from.group(1).strip()

        if write_mode == 0 and usage is not None:
            # INSERT — check for explicit column mapping
            for cname in ("Columns", "InsertColumns"):
                cols_elem = usage.find(cname)
                if cols_elem is not None:
                    for col in cols_elem:
                        v = (col.text or "").strip()
                        if v:
                            insert_columns.append(v)

        elif write_mode == 1 and usage is not None:
            # UPDATE
            sql_elem = usage.find("SQL")
            upd_stmt = sql_elem.find("UpdateStatement") if sql_elem is not None else None
            if upd_stmt is not None:
                raw_sql = (upd_stmt.text or "").strip()
                update_statement = raw_sql

                # WhereClause sub-element is authoritative
                where_elem = upd_stmt.find("WhereClause")
                if where_elem is not None:
                    update_join_keys, update_filter_conditions = parse_where_clause(
                        (where_elem.text or "").strip()
                    )

                # SET clause from raw SQL CDATA
                if raw_sql:
                    update_set_columns = parse_set_clause(raw_sql)

                # Improve table_reference: extract full "db.table" from UPDATE SQL
                # when the Tables element only gave us the database parameter
                if raw_sql and (not table_reference or "." not in table_reference):
                    m_tbl = re.match(r"UPDATE\s+(\S+)", raw_sql, re.IGNORECASE)
                    if m_tbl:
                        table_reference = m_tbl.group(1).strip()

                # is_markback: UPDATE target table matches a source table in this job
                m = re.match(r"UPDATE\s+(\S+)", raw_sql, re.IGNORECASE)
                if m:
                    update_target = m.group(1).strip()
                    bare = re.sub(r"#\$[^#]+#", "", update_target).strip(".").lower()
                    for src in job_source_tables:
                        bare_src = re.sub(r"#\$[^#]+#", "", src).strip(".").lower()
                        if bare and bare_src and bare == bare_src:
                            is_markback = True
                            break

        elif write_mode == 2 and usage is not None:
            # UPSERT — extract key columns
            for kname in ("Key", "UpsertKey", "KeyColumns"):
                key_elem = usage.find(kname)
                if key_elem is not None:
                    for k in key_elem:
                        v = (k.text or "").strip()
                        if v:
                            upsert_key_columns.append(v)
            # Also try Parameters — format: col,col,database
            sql_elem = usage.find("SQL")
            if sql_elem is not None and not upsert_key_columns:
                for stmt_tag in ("UpdateStatement", "UpsertStatement"):
                    stmt = sql_elem.find(stmt_tag)
                    if stmt is not None:
                        params_elem = stmt.find("Parameters")
                        if params_elem is not None:
                            for param in params_elem.findall("Parameter"):
                                v = (param.text or "").strip()
                                if v:
                                    # Format: "col,col,database" — first element is col name
                                    parts = v.split(",")
                                    if parts:
                                        upsert_key_columns.append(parts[0].strip())

        elif write_mode == 3 and usage is not None:
            # DELETE
            sql_elem = usage.find("SQL")
            del_stmt = sql_elem.find("DeleteStatement") if sql_elem is not None else None
            if del_stmt is not None:
                raw_sql = (del_stmt.text or "").strip()
                delete_statement = raw_sql

                where_elem = del_stmt.find("WhereClause")
                if where_elem is not None:
                    delete_key_columns = extract_where_keys(
                        (where_elem.text or "").strip()
                    )
                elif raw_sql:
                    m = re.search(r"\bWHERE\b(.*?)$", raw_sql, re.DOTALL | re.IGNORECASE)
                    if m:
                        delete_key_columns = extract_where_keys(m.group(1))

    return {
        "stage_type": "TeradataConnectorPX",
        "context": context,
        "reject_mappings": reject_mappings,
        "type_cast_map": type_cast_map,
        "write_mode": write_mode,
        "table_reference": table_reference,
        "insert_columns": insert_columns,
        "update_statement": update_statement,
        "update_set_columns": update_set_columns,
        "update_join_keys": update_join_keys,
        "update_filter_conditions": update_filter_conditions,
        "upsert_key_columns": upsert_key_columns,
        "delete_statement": delete_statement,
        "delete_key_columns": delete_key_columns,
        "is_markback": is_markback,
    }


# ─── Stage type dispatch ──────────────────────────────────────────────────────

_DISPATCH = {
    "PxChangeCapture": lambda s, rm, _: _ext_cdc(s),
    "PxAggregator": lambda s, rm, _: _ext_aggregator(s),
    "CGroupBy": lambda s, rm, _: _ext_aggregator(s),
    "PxLookup": lambda s, rm, _: _ext_lookup(s, rm),
    "PxJoin": lambda s, rm, _: _ext_join(s),
    "PxFilter": lambda s, rm, _: _ext_filter(s, rm),   # conditions[] not constraint
    "PxFunnel": lambda s, rm, _: _ext_funnel(s),
    "PxSort": lambda s, rm, _: _ext_sort(s),
    "PxSwitch": lambda s, rm, _: _ext_switch(s, rm),
    "PxMerge": lambda s, rm, _: _ext_merge(s),
    "PxDifference": lambda s, rm, _: _ext_difference(s),
    "PxModify": lambda s, rm, _: _ext_modify(s, rm),
    "PxRemDup": lambda s, rm, _: _ext_remdup(s),
    "PxCopy": lambda s, rm, _: _ext_copy(s),
    "PxSurrogateKeyGenerator": lambda s, rm, _: _ext_surrogate(s, rm),
    "PxPeek": lambda s, rm, _: _ext_peek_rowgen_tail(s, "PxPeek"),
    "PxRowGenerator": lambda s, rm, _: _ext_peek_rowgen_tail(s, "PxRowGenerator"),
    "PxTail": lambda s, rm, _: _ext_peek_rowgen_tail(s, "PxTail"),
    "PxSequentialFile": lambda s, rm, _: _ext_sequential_file(s, rm),
    "TeradataConnectorPX": lambda s, rm, src: _ext_teradata(s, rm, src),
}

def extract_job_params(job_defn: ET.Element) -> List[Dict]:
    """Extract non-password parameters from the JobDefn record."""
    params = []
    for coll in job_defn:
        if coll.tag != "Collection" or coll.get("Name") != "Parameters":
            continue
        for sub in coll:
            if sub.tag != "SubRecord":
                continue
            name = get_prop(sub, "Name")
            default = get_prop(sub, "Default") or ""
            param_type = get_prop(sub, "ParamType") or "0"
            if param_type != "1" and name:  # skip passwords
                params.append({"name": name, "default": default})
    return params


def extract_job(
    job_elem: ET.Element,
    job_name: str,
    filter_jobs: Optional[List[str]],
) -> Optional[Dict]:
    """
    Extract all gap-relevant stages from a <Job> element.
    Returns None if this job is filtered out.
    """
    if filter_jobs is not None:
        # Case-insensitive job name matching
        lower_filter = [j.lower() for j in filter_jobs]
        if job_name.lower() not in lower_filter:
            return None

    # Build a record lookup for all Records within this Job scope
    record_map: Dict[str, ET.Element] = {}
    for rec in job_elem:
        ident = rec.get("Identifier")
        if ident:
            record_map[ident] = rec

    # Find the JobDefn record for parameters
    params: List[Dict] = []
    for rec in job_elem:
        if rec.get("Type") == "JobDefn":
            params = extract_job_params(rec)
            break

    def _get_stage_type(rec: ET.Element) -> str:
        """StageType may be a direct Property or inside the CustomProperty collection."""
        return get_prop(rec, "StageType") or get_custom_prop(rec, "StageType") or ""

    # First pass: collect all source TeradataConnectorPX table references
    # Used for is_markback detection in the second pass
    source_tables: List[str] = []
    for rec in job_elem:
        if rec.get("Type") != "CustomStage":
            continue
        if _get_stage_type(rec) != "TeradataConnectorPX":
            continue
        ctx = (get_custom_prop(rec, "Context") or get_prop(rec, "Context") or "source").lower()
        if ctx == "source":
            xml_raw = get_custom_prop(rec, "XMLProperties") or ""
            if xml_raw:
                xp = parse_xml_props(xml_raw)
                if xp is not None:
                    tbl = xp_text(xp, "Usage", "TableName") or xp_text(xp, "Tables", "Table")
                    if tbl:
                        source_tables.append(tbl)

    # Second pass: extract all stages
    stages: List[Dict] = []
    stage_count_by_type: Dict[str, int] = {}

    for rec in job_elem:
        rec_type = rec.get("Type", "")
        stage_name = get_prop(rec, "Name") or rec.get("Identifier", "")

        data: Optional[Dict] = None

        # TransformerStage is a distinct Record type
        if rec_type == "TransformerStage":
            data = _ext_transformer(rec, record_map)

        elif rec_type == "CustomStage":
            stage_type = _get_stage_type(rec)
            if stage_type == "CTransformerStage":
                data = _ext_transformer(rec, record_map)
            elif stage_type in _DISPATCH:
                try:
                    data = _DISPATCH[stage_type](rec, record_map, source_tables)
                except Exception as exc:
                    data = {"stage_type": stage_type, "extract_error": str(exc)}
            # Unknown stage types are silently skipped

        if data is not None:
            data["stage_name"] = stage_name
            stages.append(data)
            st = data["stage_type"]
            stage_count_by_type[st] = stage_count_by_type.get(st, 0) + 1

    return {
        "job_name": job_name,
        "parameters": params,
        "stages": stages,
        "_stage_counts": stage_count_by_type,
    }


# ─── Main extraction ──────────────────────────────────────────────────────────

def extract_dsx(
    dsx_path: str,
    filter_jobs: Optional[List[str]] = None,
) -> Dict:
    """
    Parse a DSX/XML file and return a compact profile dict.
    Raises RuntimeError on parse failure.
    """
    try:
        tree = ET.parse(dsx_path)
    except ET.ParseError as exc:
        raise RuntimeError(f"XML parse error in {dsx_path}: {exc}") from exc

    root = tree.getroot()

    # Support both <DSExport> and bare-root formats
    if root.tag != "DSExport":
        raise RuntimeError(f"Expected <DSExport> root, got <{root.tag}>")

    # Read header metadata
    header = root.find("Header")
    tool_instance = header.get("ToolInstanceID", "") if header is not None else ""
    server = header.get("ServerName", "") if header is not None else ""

    jobs_output: List[Dict] = []
    all_job_names: List[str] = []

    for job_elem in root.findall("Job"):
        job_id = job_elem.get("Identifier", "")
        # Job name is in the JobDefn record's Name property, or the Job Identifier
        job_name = job_id
        for rec in job_elem:
            if rec.get("Type") == "JobDefn":
                n = get_prop(rec, "Name")
                if n:
                    job_name = n
                break
        all_job_names.append(job_name)

        extracted = extract_job(job_elem, job_name, filter_jobs)
        if extracted is not None:
            jobs_output.append(extracted)

    return {
        "source_file": os.path.basename(dsx_path),
        "tool_instance": tool_instance,
        "server": server,
        "all_job_names": all_job_names,
        "jobs": jobs_output,
    }


# ─── CLI ──────────────────────────────────────────────────────────────────────

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Extract gap-relevant data from a DataStage DSX XML file into a JSON profile.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("dsx_file", help="Path to the .dsx or .xml file")
    parser.add_argument(
        "--jobs",
        metavar="JOB1,JOB2",
        help="Comma-separated list of job names to extract (default: all)",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Re-extract even if the profile is already up to date",
    )
    parser.add_argument(
        "--out",
        metavar="PATH",
        help="Output path for JSON profile (default: <dsx_stem>_profile.json)",
    )
    parser.add_argument(
        "--list-jobs",
        action="store_true",
        help="Print all job names in the DSX and exit",
    )
    args = parser.parse_args()

    dsx_path = args.dsx_file
    if not os.path.isfile(dsx_path):
        print(f"ERROR: file not found: {dsx_path}", file=sys.stderr)
        return 2

    # Determine output path
    if args.out:
        out_path = args.out
    else:
        stem = os.path.splitext(dsx_path)[0]
        out_path = stem + "_profile.json"

    # --list-jobs: quick scan for job names
    if args.list_jobs:
        try:
            tree = ET.parse(dsx_path)
        except ET.ParseError as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1
        root = tree.getroot()
        for job_elem in root.findall("Job"):
            name = job_elem.get("Identifier", "")
            for rec in job_elem:
                if rec.get("Type") == "JobDefn":
                    n = get_prop(rec, "Name")
                    if n:
                        name = n
                    break
            print(name)
        return 0

    # Cache check: skip if profile is newer than DSX (unless --force)
    if not args.force and os.path.isfile(out_path):
        dsx_mtime = os.path.getmtime(dsx_path)
        prof_mtime = os.path.getmtime(out_path)
        if prof_mtime >= dsx_mtime:
            print(f"Profile is up to date: {out_path}  (use --force to re-extract)")
            return 0

    filter_jobs = None
    if args.jobs:
        filter_jobs = [j.strip() for j in args.jobs.split(",") if j.strip()]

    try:
        profile = extract_dsx(dsx_path, filter_jobs=filter_jobs)
    except RuntimeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        print(
            "Fallback: paste the DSX file directly — the agent will parse it manually.",
            file=sys.stderr,
        )
        return 1

    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(profile, fh, indent=2, ensure_ascii=False)

    # Summary to stdout
    total_stages = sum(len(j["stages"]) for j in profile["jobs"])
    dsx_kb = os.path.getsize(dsx_path) // 1024
    prof_kb = os.path.getsize(out_path) // 1024
    print(
        f"Extracted {len(profile['jobs'])} job(s), {total_stages} stages "
        f"from {os.path.basename(dsx_path)} ({dsx_kb}KB -> {prof_kb}KB profile)"
    )
    for job in profile["jobs"]:
        counts = job.get("_stage_counts", {})
        summary = "  ".join(f"{k}:{v}" for k, v in sorted(counts.items()))
        print(f"  {job['job_name']}  [{summary}]")
    print(f"Profile written: {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
