# DSX Parse Rules — DataStage XML Reconciliation
# Version: 2026-04-14
# Loaded in Step 0-A only — when input contains a <DSExport> XML file.
# Covers all 22 DataStage processing stage types.

---

## SECTION 1 — Detection and Input Patterns

A DSX file is present when input contains one or more files with `<DSExport>` as the root element
(`.dsx` or `.xml` extension, or content starting with `<DSExport`).

If detected: run Step 0-A before all notebook indexing. Store extracted data as dsx_profile.

### Three supported input patterns

**Pattern A — Paired files (one DSX per notebook):**
User pastes multiple `.py` + `.xml` pairs, e.g. `step1.py` + `step1.xml`, `step2.py` + `step2.xml`.
Each XML file contains exactly one `<Record Type="JobDefn">` and maps to its paired notebook.

Detection: multiple `<DSExport>` files present in input.

Mapping rule: match by filename stem first — `step1.xml` maps to `step1.py` (case-insensitive stem comparison).
If stem match fails, fall back to content matching (Section 5).

**Pattern B — Single multi-job DSX (one XML contains all jobs):**
User pastes N notebooks + one `.xml` file that contains multiple `<Record Type="JobDefn">` blocks.
All jobs are exported into a single DSX file.

Detection: one `<DSExport>` file AND multiple `<Record Type="JobDefn">` blocks inside it.

Mapping rule: content matching only — use `# Original DS name: {stage_name}` in traceability blocks
to map each stage to the correct notebook (Section 5).

**Pattern C — Single job DSX (original pattern):**
User pastes N notebooks + one `.xml` file with exactly one `<Record Type="JobDefn">`.

Detection: one `<DSExport>` file AND exactly one `<Record Type="JobDefn">`.

Mapping rule: content matching — `# Original DS name: {stage_name}` across all notebooks.

---

**Processing rule for all patterns:**
Iterate over every `<Record Type="JobDefn">` found across all DSX files.
Extract stages and parameters per job (Sections 4A–4X).
Store all extracted stages in dsx_profile, tagged with their `job_name`.

---

### Large DSX File Strategy (file > 30K characters)

When a single DSX file exceeds 30K characters, a full immediate parse of every job block
is expensive and error-prone. Apply this pre-filter before any stage extraction:

**Step 1 — Light job-name pass (scan entire file, extract names only):**

Scan the full DSX for every `<Record Type="JobDefn">` block.
For each, extract only the job name from:
`<Property Name="Name">{job_name}</Property>` — the first Name property inside that JobDefn.
Do NOT extract any stages yet. Build: `all_job_names[]`.

**Step 2 — Match job names against pasted notebooks:**

Apply the Section 5 matching algorithm to `all_job_names[]`:
- Filename stem match: does any notebook filename contain the job name (case-insensitive)?
- Content match: does any notebook contain `# Original DS name: {stage_name}` where that stage
  belongs to this job (scan traceability blocks across all pasted notebooks)?

Result: `matched_jobs[]` = jobs that map to at least one pasted notebook.
Unmatched jobs → skip entirely — do not parse their stage blocks.

**Step 3 — Deep parse matched jobs only:**

For each job in `matched_jobs[]`: apply the full Section 4 extraction (4A–4X) to that job block only.
Apply Section 5 stage-to-notebook mapping as normal.
All gap detection (Section 6) and patch generation (Section 7) proceed unchanged.

**What to report (add to DSX GAP REPORT header when pre-filter was used):**
```
DSX file : {filename}   Size: {n}K — pre-filter mode
Jobs in file : {total}   Matched to notebooks : {n}   Skipped (no notebook match) : {n}
```

**Never output "file too large — re-run with individual exports."**
Pre-filter mode always produces a complete gap report for matched jobs.
Unmatched jobs are irrelevant — their stages have no corresponding notebook to fix.

---

## SECTION 2 — Decoding (apply before extracting any value)

Two layers of encoding appear in DSX properties. Both must be decoded.

### 2A. XML Entity Decoding

Apply to every property value before use:

| Entity    | Decoded character |
|-----------|-------------------|
| `&apos;`  | `'`               |
| `&lt;`    | `<`               |
| `&gt;`    | `>`               |
| `&amp;`   | `&`               |
| `&quot;`  | `"`               |

### 2B. Escape Sequence Decoding

Apply to multi-value list properties (`key`, `dropvalue`, `groupKey`, `sortKey`, etc.):

| Sequence | Meaning                                   |
|----------|-------------------------------------------|
| `\(1)`   | Record separator — between list entries   |
| `\(2)`   | Field separator — within an entry         |
| `\(3)`   | Property name marker                      |
| `\(20)`  | Empty / null                              |

**Extraction algorithm for list-type properties:**
1. Split raw value on `\(1)\(3){property_name}\(2)` — one segment per entry
2. Discard first segment (header — always starts with `\(2)\(2)0`)
3. Per remaining segment: column name = text up to next `\(2)` (before trailing `\(2)0`)
4. Collect all names as a list

**Real example** — CDC `dropvalue` property value:
```
\(2)\(2)0\(1)\(3)dropvalue\(2)DATA_VALD_BGN_TS\(2)0\(1)\(3)dropvalue\(2)CREAT_TS\(2)0
```
Split on `\(1)\(3)dropvalue\(2)` → segments after header: `DATA_VALD_BGN_TS\(2)0`, `CREAT_TS\(2)0`
Extract up to `\(2)` → `DATA_VALD_BGN_TS`, `CREAT_TS`

---

## SECTION 3 — Stage Type Identification Map

| XML pattern | DataStage stage type | PySpark equivalent |
|---|---|---|
| `<Record Type="JobDefn">` | Job definition | — parameters and job name |
| `StageType=PxChangeCapture` | Change Capture | CDC — detect insert/update/delete |
| `StageType=PxAggregator` or `CGroupBy` | Aggregator | `.groupBy().agg()` |
| `Type="TransformerStage"` or `StageType=CTransformerStage` | Transformer | `.withColumn()` chains + stage variables |
| `StageType=PxLookup` | Lookup | `LEFT JOIN` reference |
| `StageType=PxJoin` | Join | `.join()` inner/left/right/full |
| `StageType=PxFilter` | Filter | `.filter()` / `.where()` |
| `StageType=PxFunnel` | Funnel | `union()` / `unionAll()` |
| `StageType=PxSort` | Sort | `.orderBy()` |
| `StageType=PxChecksum` | Checksum | `F.md5(F.concat_ws(...))` |
| `StageType=PxSwitch` | Switch | Conditional routing — multiple `.filter()` outputs |
| `StageType=PxMerge` | Merge | `JOIN` with update/insert logic |
| `StageType=PxDifference` | Difference | `.subtract()` or anti-join |
| `StageType=PxModify` | Modify | Column rename / drop / reorder |
| `StageType=PxColumnExport` | Column Export | `F.concat_ws(delimiter, cols...)` |
| `StageType=PxColumnImport` | Column Import | `F.split(col, delimiter)` element extraction |
| `StageType=PxPivot` | Pivot | `.groupBy().pivot().agg()` |
| `StageType=PxRemDup` | Remove Duplicates | `.dropDuplicates()` |
| `StageType=PxSurrogateKeyGenerator` | Surrogate Key Generator | `row_number()` + max lookup |
| `StageType=PxCopy` | Copy | DataFrame replication to multiple outputs |
| `StageType=PxPeek` | Peek | Row logging — remove in production |
| `StageType=PxRowGenerator` | Row Generator | Test data — flag for removal |
| `StageType=PxTail` | Tail | `.orderBy(desc).limit(n)` |
| `StageType=PxSequentialFile` | Sequential File | Source/target file — extracted in Section 4X |
| `StageType=TeradataConnectorPX` | Teradata Connector | Source/target table — extracted in Section 4W |

---

## SECTION 4 — Per-Stage Extraction Rules

### 4A. Job Parameters

From `<Record Type="JobDefn">` → `<Collection Name="Parameters" Type="Parameters">`:
- Each `<SubRecord>`: name (`<Property Name="Name">`), default (`<Property Name="Default">`),
  type (`<Property Name="ParamType">`: 0=string, 1=password)
- Collect all **non-password** parameters as expected widget declarations

### 4B. PxChangeCapture (CDC)

For each `<Record Type="CustomStage">` where `<Property Name="StageType">PxChangeCapture`:

| Extract | XML source | Notes |
|---|---|---|
| `stage_name` | `<Property Name="Name">` | |
| `key_columns` | `<Property Name="key">` | escape decoder, split on `\(1)\(3)key\(2)` |
| `exempt_columns` | `<Property Name="dropvalue">` | escape decoder; if absent or `\(20)` only → `[]` |
| `selection` | `<Property Name="selection">` | `allvalues` or `changedvalues` |

### 4C. PxAggregator / CGroupBy

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `group_key_columns` | `<Property Name="groupKey">` — escape decoder |
| `aggregate_expressions` | Output pin column `<Property Name="Derivation">` values — XML entity decode |

### 4D. TransformerStage — Column Derivations

For each `<Record Type="TransformerStage">` or `Type="CustomStage"` where `StageType=CTransformerStage`:

Per output pin (`<Record Type="TrxOutput">`):
- `link_name` ← `<Property Name="Name">`
- `constraint` ← `<Property Name="Constraint">` — decode XML entities; empty string = no constraint
- `reject` ← `<Property Name="Reject">` — 0 = data output, 1 = reject link

Per output column in `<Collection Name="Columns" Type="OutputColumn">`:
- `col_name` ← `<Property Name="Name">`
- `derivation` ← `<Property Name="ParsedDerivation">` if present, else `<Property Name="Derivation">`
  — decode XML entities; strip leading `\(20)` if present
- A derivation of the form `LinkName.ColumnName` (simple passthrough) is not a gap — skip

### 4E. TransformerStage — Stage Variables (CRITICAL)

Within the same Transformer record: `<Collection Name="StageVars" Type="StageVar">`

Per `<SubRecord>`:

| Extract | XML source | Notes |
|---|---|---|
| `var_name` | `<Property Name="Name">` | |
| `expression` | `ParsedExpression` else `Expression` | decode XML entities; strip leading `\(20)` |
| `initial_value` | `<Property Name="InitialValue">` | **if present → STATEFUL variable** |
| `depends_on_vars` | `<Property Name="StageVars">` | semicolon-separated names |
| `sql_type` | `<Property Name="SqlType">` | 12=string, 3=decimal, 1=char |

**Stage variable categories:**
- **Stateless** (no `InitialValue`): recomputed fresh per row → maps to `.withColumn()`
- **Stateful** (has `InitialValue`): persists value across rows within a partition →
  requires Window function or `mapPartitions`; Lakebridge commonly generates wrong PySpark

**Real example from `wwspax46_Step03_CDC.xml`:**
- `SPANOERR1` — `If IsNull(lnkChanges.SS_SPA_NO) Then '5005' Else ...` — **stateless**
- `DLRACCTNOERR1`, `DLRLOCCDERR1`, `ADJIDERR1` — similar validation flags — **stateless**
- `REJECTRECORD` — `If (SPANOERR1 <> '' Or ...) Then 'Y' Else 'N'`, `InitialValue='N'` — **STATEFUL**

### 4F. PxLookup

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `lookup_fail` | `<Property Name="LookupFail">` on the reference input pin — `reject` or `fail` |
| Reference pin | Identified by `<Property Name="LinkType">2` |

### 4G. PxJoin

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `join_type` | MetaBag property `join_type` — `inner`, `left outer`, `right outer`, `full outer` |
| `key_columns` | `<Property Name="key">` — escape decoder |

### 4H. PxFilter

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `constraint` | `<Property Name="Constraint">` on stage output pin — decode XML entities |

### 4I. PxFunnel

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `input_pin_count` | Count of `\|` separators + 1 in `<Property Name="InputPins">` |
| `funnel_type` | MetaBag `funnel_type` — `sorted` or `unsorted` |

### 4J. PxSort

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `sort_keys` | `<Property Name="sortKey">` — escape decoder; direction suffix `A`=ascending, `D`=descending |

### 4K. PxChecksum

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `checksum_columns` | Output column `Derivation` values referencing input columns |
| `algorithm` | MetaBag checksum algorithm property — default `md5` if absent |

### 4L. PxSwitch

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| Per output pin: `output_name`, `condition` | `<Property Name="Constraint">` — decode XML entities |

### 4M. PxMerge

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `key_columns` | `<Property Name="key">` — escape decoder |
| `merge_type` | MetaBag merge type property |

### 4N. PxDifference

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `key_columns` | `<Property Name="key">` — escape decoder |

### 4O. PxModify

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| Per output column: `col_name`, `derivation` | `col_name` = renamed target; `derivation` = source column name or empty if dropped |

### 4P. PxColumnExport

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `delimiter` | MetaBag or Properties delimiter property |
| `source_columns` | Input column list in order (link column definitions) |
| `target_column` | Output column name |

### 4Q. PxColumnImport

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `delimiter` | MetaBag or Properties delimiter property |
| `source_column` | Input column containing the delimited string |
| `target_columns` | Output column list in order |

### 4R. PxPivot

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `pivot_key` | MetaBag pivot key column property |
| `pivot_values` | MetaBag pivot value list property |
| `aggregate_column` | MetaBag aggregate column property |
| `aggregate_function` | MetaBag aggregate function property |

### 4S. PxRemDup

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `key_columns` | `<Property Name="key">` — escape decoder |
| `keep_first` | MetaBag retain property — first or last |

### 4T. PxSurrogateKeyGenerator

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `key_column` | Output column where `<Property Name="KeyPosition">` > 0 |
| `start_value` | MetaBag start value property |
| `increment` | MetaBag increment property |

### 4U. PxCopy

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `output_pin_count` | Count of `\|` separators + 1 in `<Property Name="OutputPins">` |

### 4V. PxPeek / PxRowGenerator / PxTail

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `tail_n` (PxTail only) | MetaBag tail count property |

### 4W. TeradataConnectorPX

For each `<Record>` where `<Property Name="StageType">TeradataConnectorPX`:

**Two-pass extraction — complete Step 1 fully before Step 2. They operate on different XML levels.**

---

#### Step 1 — Outer record extraction (perform this first, before any XMLProperties work)

The following fields are in the outer `<Record>` XML, at the same level as `<Property Name="Name">`.
They are NOT inside the XMLProperties embedded string.

| Extract | XML source | Notes |
|---|---|---|
| `stage_name` | `<Property Name="Name">` | |
| `context` | Properties → Context attribute | `source` or `target` |
| `reject_mappings` | MetaBag → MappingRejectAdd | Pipe-separated reject column defs |

**Column type extraction — also part of Step 1 (outer XML, NOT inside XMLProperties):**

For every stage where `context=target`:

**Column definitions come from the upstream stage's output pin, reached via the input pin's Partner link.**
Extraction path:
1. Read `<Property Name="InputPins">` from the stage record → pipe-separated list of input pin identifiers (e.g. `V38S1P1`)
2. For each pin ID: find `<Record Identifier="{pin_id}" Type="CustomInput">` elsewhere in the DSX
3. Read `<Property Name="Partner">` on that CustomInput record → format `"StageIdentifier|PinIdentifier"` (e.g. `V38S0|V38S0P2`) — take the last segment after `|` to get the upstream output pin ID
4. Find `<Record Identifier="{upstream_pin_id}">` (any Type — may be `TrxOutput`, `CustomOutput`, etc.)
5. Inside that record, read `<Collection Name="Columns" Type="OutputColumn">`
6. Per `<SubRecord>`: read `<Property Name="Name">`, `<Property Name="SqlType">`, `<Property Name="Precision">`, `<Property Name="Scale">`

The upstream stage's output pin carries the exact schema of data flowing into the Teradata target — this is the authoritative source for type casting.

- Build `type_cast_map` — include ONLY castable types:

| SqlType code | Cast string to store |
|---|---|
| 3 (DECIMAL) | `decimal({Precision},{Scale})` |
| 4 (INTEGER) | `int` |
| 5 (SMALLINT) | `smallint` |
| -5 (BIGINT) | `bigint` |
| 9 (DATE) | `date` |
| 11 (TIMESTAMP) | `timestamp` |
| 92 (TIME) | `time_hms` — sentinel; emit `F.date_format(F.col("{col}"), "HH:mm:ss")` in D-TERA-CAST cell, NOT `.cast()`. Spark has no native TIME type. |

Skip SqlType 1 (CHAR) and 12 (VARCHAR) — no cast needed. These do not appear in `type_cast_map`.
If no castable columns: `type_cast_map = {}` — no gap raised for this stage.

Step 1 is now complete. Proceed to Step 2.

---

#### Step 2 — XMLProperties extraction (inner embedded XML, separate nested parse)

`<Property Name="XMLProperties">` contains an *embedded XML string* inside its value.
Parse it as a second, nested XML document. It is entirely separate from the outer record XML.
Key elements inside this embedded XML: `<WriteMode>`, `<UpdateStatement>`, `<DeleteStatement>`, `<Tables>/<Table>`.

| Extract | XMLProperties element | Notes |
|---|---|---|
| `write_mode` | `<WriteMode>` | 0=insert, 1=update, 2=upsert, 3=delete |
| `update_statement` | `<UpdateStatement>` | Full SQL — decode XML entities |
| `delete_statement` | `<DeleteStatement>` | Full SQL — decode XML entities |
| `table_reference` | `<Tables>/<Table>` | May contain `#$TERA_*#` placeholders |

**When WriteMode=0 (INSERT):**
- Check XMLProperties for an explicit column mapping element (`<Columns>` or `<InsertColumns>`).
- If column mapping present: extract ordered column list → store as `insert_columns: ["col1", "col2", ...]`
- If no column mapping: store `insert_columns: []` — means insert-all, existing `.write.saveAsTable()` is correct, no gap raised.

**`ORCHESTRATE.` alias — applies to all WriteMode=1 parsing:**
DataStage uses `ORCHESTRATE.col_name` as its internal alias for columns coming from the input link (the incoming DataFrame). When translating to PySpark:
- `ORCHESTRATE.col_name` → `s.col_name` (source alias in DeltaTable merge)
- Unqualified `col_name` in a SET or WHERE target context → `t.col_name` (target alias)
This substitution applies inside both SET values and CASE WHEN expressions.

**When WriteMode=1 (UPDATE):**
The `<UpdateStatement>` element (inside `<SQL>` inside `<Usage>`) has sub-elements — use them directly:
- `<WhereClause>` sub-element → authoritative structured WHERE clause. Use this instead of parsing raw SQL.
- `<Parameters>` sub-elements → bound parameters in `col,col,database` format — cross-reference to confirm join key column names.
- CDATA block → raw SQL text — use only for the patch comment header, not for parsing.

**Extract SET clause** from the raw SQL CDATA. For each `SET col = value` pair, classify:

  | Value pattern | value_type | PySpark translation |
  |---|---|---|
  | `ORCHESTRATE.col_name` | `col_ref` | `F.col("s.col_name")` — strip `ORCHESTRATE.` prefix |
  | Single-quoted string: `'literal'` | `literal_string` | `F.lit("literal")` |
  | Unquoted number: `42`, `3.14` | `literal_number` | `F.lit(42)` |
  | `CURRENT_TIMESTAMP`, `CAST(...)`, `CASE WHEN...` — any SQL expression | `sql_expr` | `F.expr("expression")` — replace `ORCHESTRATE.col` with `s.col`, unqualified col with `t.col` inside the expression |

  Store as: `update_set_columns: [{"col": col_name, "value": raw_value, "value_type": "col_ref"|"literal_string"|"literal_number"|"sql_expr"}, ...]`

**Extract WHERE clause** from `<WhereClause>` sub-element. Classify each condition:
  - `col = ORCHESTRATE.col` → **join condition** — links incoming row to target row → `t.col = s.col`
  - `col = 'literal'` or `col = value` → **target filter** — filters target rows only → `t.col = 'literal'`

  Store separately:
  - `update_join_keys: ["col1", ...]` — columns from join conditions (one per `col = ORCHESTRATE.col`)
  - `update_filter_conditions: ["t.col = 'literal'", ...]` — rendered strings from target filter conditions

  Full merge condition = all join conditions + all filter conditions joined with ` AND `.

- Store full original SQL as `update_statement` (decoded) for reference in the patch comment.
- Determine `update_target` from the UPDATE target table. Set `is_markback=True` if `update_target` (resolved) matches any source stage table in the same job.

**When WriteMode=2 (UPSERT):**
- Extract key columns from XMLProperties key definition.
- Store as `upsert_key_columns: ["col1", "col2", ...]`

**When WriteMode=3 (DELETE):**
- Parse `DeleteStatement` SQL fully — decode all XML entities first.
- Extract WHERE clause: collect all key column names from equality conditions.
- Store as: `delete_key_columns: ["col1", "col2", ...]`
- Store full original SQL as `delete_statement` for reference in the patch comment.

---

**dsx_table_map entry:** After completing both steps for every TeradataConnectorPX stage, build a per-job registry:

```
dsx_table_map[job_name][stage_name] = {
    "table_reference": ...,    # raw value from XMLProperties (may have #$TERA_*# placeholders)
    "context": "source"|"target",
    "write_mode": 0|1|2|3,    # 0=insert, 1=update, 2=upsert, 3=delete
    "is_markback": True|False,
    "insert_columns": [...],   # WriteMode=0 only — ordered list of column names; [] means insert-all
    "update_statement": "...", # WriteMode=1 only — full original SQL (decoded)
    "update_set_columns": [{"col": "col_name", "value": "raw_value", "value_type": "col_ref"|"literal_string"|"literal_number"|"sql_expr"}, ...],  # WriteMode=1 only
    "update_join_keys": [...],      # WriteMode=1 only — cols from join conditions: col = ORCHESTRATE.col
    "update_filter_conditions": ["t.col = 'literal'", ...],  # WriteMode=1 only — target-side filter conditions (rendered strings)
    "upsert_key_columns": [...],    # WriteMode=2 only
    "delete_statement": "...", # WriteMode=3 only — full original SQL (decoded)
    "delete_key_columns": [...],    # WriteMode=3 only — key columns from WHERE clause
    "type_cast_map": {},            # {col_name: "decimal(p,s)"|"int"|"smallint"|"bigint"|"date"|"timestamp"|"time_hms"} — empty when no castable columns
}
```

Pass `dsx_table_map` into the Step 4 report (TABLE MAP section) and use it in Group N rules as the
highest-priority source for widget `defaultValue` resolution — above script profile, above notebook patterns.

### 4X. PxSequentialFile

For each `<Record>` where `<Property Name="StageType">PxSequentialFile`:

| Extract | XML source | Notes |
|---|---|---|
| `stage_name` | `<Property Name="Name">` | |
| `context` | Properties → Context attribute | `source` or `target` |
| `file_path` | XMLProperties → `<Filename>` | May be parameterized |
| `file_suffix` | Derived from `file_path` | e.g. `_current.dat`, `_Inserts_Key.dat` |

**Delta table name derivation (when `context=target`):**
Derive as `{TARGET_TABLE_NAME}_{STAGE_SUFFIX}` where:
- `TARGET_TABLE_NAME` = the job's TeradataConnectorPX target stage table name (from 4W), with `#$TERA_*#` stripped
- `STAGE_SUFFIX` = `stage_name` with any common job-prefix stripped (lower-cased, underscored)

Add derived name to `dsx_table_map` for cross-notebook consistency — the same intermediate file
must resolve to the same Delta table name in both the producer notebook and the consumer notebook.

---

## SECTION 5 — Job-to-Notebook Mapping

Apply the mapping algorithm that matches the detected input pattern (Section 1).

### Step 1 — Filename stem match (Pattern A only)

For each DSX file in the input:
1. Extract the filename stem (e.g. `step1` from `step1.xml`)
2. Search pasted notebook filenames for a case-insensitive stem match (e.g. `step1.py`)
3. If match found → assign HIGH confidence, all stages from that DSX map to that notebook
4. If no match → fall through to Step 2 (content match) for that DSX file

### Step 2 — Content match (all patterns, fallback for Pattern A)

For each `stage_name` not yet mapped by Step 1:
1. Search all pasted notebook content for `# Original DS name: {stage_name}` in traceability blocks
2. If found (exact) → HIGH confidence
3. If found (case-insensitive only) → MEDIUM confidence
4. If not found in any notebook → LOW confidence → mark as UNMATCHED

### Recording results

Record as: `{notebook_filename: [stage_names_mapped_to_it]}` with confidence per stage.

Unmatched stages → note as `UNMATCHED` in the DSX GAP REPORT.
Do not generate a fix for unmatched stages — cannot locate the cell.

### Multi-job DSX note

When one DSX contains multiple `<Record Type="JobDefn">` blocks: each job's stages are extracted
and mapped independently via content match. D-PARAM gap checks are per-job: each job's non-password
parameters must appear as widgets in the notebooks mapped to that job.

---

## SECTION 6 — Gap Detection Rules

Apply each rule against the matched notebook cell after entity and escape decoding.
All gaps are REVIEW confidence — engineer must verify before production.

| Gap ID | Stage type | Trigger condition | Severity |
|---|---|---|---|
| D-CDC-EXEMPT | PxChangeCapture | `exempt_columns` non-empty AND none of those column names appear in a filter/exclusion context in the CDC cell | HIGH |
| D-CDC-KEY | PxChangeCapture | `key_columns` from DSX absent from the change detection join or comparison columns in CDC cell | HIGH |
| D-AGG-KEY | PxAggregator | One or more `group_key_columns` missing from `.groupBy()` arguments | HIGH |
| D-AGG-EXPR | PxAggregator | DSX aggregate expressions not represented in `.agg()` call | HIGH |
| D-TRANSFORM-CONSTRAINT | TransformerStage | Output pin `constraint` non-empty AND no `.filter()` or routing on that output link | HIGH |
| D-TRANSFORM-DERIVATION | TransformerStage | Column `derivation` is non-trivial BASIC (not `Link.Col` passthrough) AND BASIC function names still present in the notebook cell | HIGH |
| D-STAGEVAR-MISSING | TransformerStage | Stage variable `var_name` absent (no `.withColumn("{var_name}", ...)` in the transformer cell) | HIGH |
| D-STAGEVAR-EXPR | TransformerStage | Stage variable present but its `.withColumn()` expression still contains unconverted BASIC function names | HIGH |
| D-STAGEVAR-STATEFUL | TransformerStage | Stage variable has `InitialValue` AND the notebook uses simple `.withColumn()` without a Window function | CRITICAL |
| D-FILTER | PxFilter | DSX filter `constraint` not present as `.filter()` / `.where()` in notebook | HIGH |
| D-LOOKUP-FAIL | PxLookup | `lookup_fail=reject` AND no reject-path handling in notebook | MEDIUM |
| D-JOIN-TYPE | PxJoin | DSX `join_type` does not match `.join(..., how=...)` argument | HIGH |
| D-SORT-KEY | PxSort | DSX sort keys or directions differ from `.orderBy()` arguments | MEDIUM |
| D-CHECKSUM | PxChecksum | Checksum columns or algorithm differ from DSX | MEDIUM |
| D-SWITCH | PxSwitch | One or more DSX output pin conditions absent from notebook routing | HIGH |
| D-MERGE | PxMerge | Merge key columns or merge logic incomplete vs DSX | HIGH |
| D-DIFFERENCE | PxDifference | Set difference key columns differ from DSX | MEDIUM |
| D-MODIFY | PxModify | Column rename / drop / reorder differs from DSX output column spec | MEDIUM |
| D-COL-EXPORT | PxColumnExport | Delimiter, column list, or column order differs from DSX | MEDIUM |
| D-COL-IMPORT | PxColumnImport | Delimiter or target column mapping differs from DSX | MEDIUM |
| D-PIVOT | PxPivot | Pivot key, values, or aggregate function differ from DSX | HIGH |
| D-REMDUP | PxRemDup | Dedup key columns differ from DSX | HIGH |
| D-SURROGATE | PxSurrogateKeyGenerator | `start_value` or `increment` differ from DSX | MEDIUM |
| D-FUNNEL-COUNT | PxFunnel | `union()` input count ≠ DSX input pin count | HIGH |
| D-COPY-COUNT | PxCopy | DataFrame not replicated to the expected number of outputs | MEDIUM |
| D-PEEK | PxPeek | Stage present in DSX — debug logging, must be removed before production | LOW |
| D-ROWGEN | PxRowGenerator | Stage present in DSX — test data generator, must not exist in production | MEDIUM |
| D-TAIL | PxTail | Tail size `n` differs from DSX or not implemented as `.orderBy(desc).limit(n)` | LOW |
| D-TERA-INSERT | TeradataConnectorPX | WriteMode=0 AND `insert_columns` non-empty AND notebook write cell does not `.select()` those columns before `.write.saveAsTable()` | MEDIUM |
| D-TERA-UPDATE | TeradataConnectorPX | WriteMode=1 AND notebook uses `.whenMatchedUpdateAll()` or `.write.saveAsTable()` instead of specific column-level update derived from UpdateStatement | HIGH |
| D-TERA-UPSERT | TeradataConnectorPX | WriteMode=2 AND notebook uses `.write.saveAsTable()` or `.write.mode("overwrite")` instead of a keyed DeltaTable merge derived from upsert_key_columns | HIGH |
| D-TERA-DELETE | TeradataConnectorPX | WriteMode=3 AND notebook has no `.whenMatchedDelete()` or equivalent row-deletion logic derived from DeleteStatement | HIGH |
| D-TERA-TARGET | TeradataConnectorPX | `is_markback=True` AND notebook generates a separate `target_table` widget instead of reusing `source_table` (mark-back pattern misidentified as separate target) | HIGH |
| D-TERA-TABLE | TeradataConnectorPX | `table_reference` from XMLProperties (resolved) does not match notebook's target widget `defaultValue` | HIGH |
| D-TERA-CAST | TeradataConnectorPX | `context=target` AND `type_cast_map` non-empty AND the notebook's target write cell has no explicit `.cast()` or `F.date_format()` for any column listed in `type_cast_map` | MEDIUM |
| D-PARAM | JobDefn | Non-password DSX parameter has no `dbutils.widgets.text()` in any notebook | MEDIUM |

---

## SECTION 7 — Fix Patch Templates

**Constraints — apply to every patch:**
- Always use the actual DataFrame variable name from the notebook traceability block — never hardcode
- Always use `F.` prefix for all PySpark functions
- New cell patches (D-CDC-EXEMPT, D-TRANSFORM-CONSTRAINT, D-STAGEVAR-STATEFUL, D-SWITCH, D-TERA-INSERT, D-TERA-UPDATE, D-TERA-UPSERT, D-TERA-DELETE, D-TERA-CAST):
  inject as new `# COMMAND ----------` block at the correct position
- All other patches: inline `# REVIEW:` comment in the relevant existing cell
- Never rename DataFrame variables or move traceability block comments

---

### D-CDC-EXEMPT — new cell before target write

```python
# COMMAND ----------
# DSX EXEMPT COLUMNS — PxChangeCapture "dropvalue", stage: {stage_name}
# Rows where ONLY these columns changed → NO CHANGE in DataStage (not treated as an update).
# Key columns    : {comma-separated key_columns}
# Exempt columns : {comma-separated exempt_columns}
#
# REVIEW: implement exempt-column filtering before the target write below.
# Example — adjust column prefix conventions to match your CDC cell:
#   _exempt = [{quoted list of exempt col names}]
#   _key    = [{quoted list of key col names}]
#   _compare_cols = [c for c in {df_var}.columns if c not in _exempt + _key]
#   {df_var} = {df_var}.filter(
#       F.exists(F.array(*[F.col(f"before_{c}") != F.col(f"after_{c}") for c in _compare_cols]),
#                lambda x: x))
# REVIEW: verify column prefix conventions and exempt column list before running
```

### D-CDC-KEY — inline comment

```python
# REVIEW: DSX CDC key columns: {comma-separated list} — verify these are the join/comparison keys above.
```

### D-AGG-KEY / D-AGG-EXPR — inline comment

```python
# REVIEW: DSX aggregator "{stage_name}" group keys: {list} — verify .groupBy() is complete
# REVIEW: DSX aggregate expressions: {list} — verify .agg() is complete
```

### D-TRANSFORM-CONSTRAINT — new cell

```python
# COMMAND ----------
# REVIEW: DSX transformer output "{link_name}" routing constraint: {constraint_expression}
# Verify a .filter() implementing this condition routes rows to the "{link_name}" output.
```

### D-TRANSFORM-DERIVATION — inline comment

```python
# REVIEW: DSX derivation for {col_name}: {expression}
# Verify the .withColumn() above correctly converts this BASIC expression to PySpark.
```

### D-STAGEVAR-MISSING — inline comment in transformer cell

```python
# REVIEW: DSX stage variable "{var_name}" missing from this cell.
# Expected: .withColumn("{var_name}", {converted_expression})
# DSX expression (BASIC): {expression}
```

### D-STAGEVAR-EXPR — inline comment on the .withColumn()

```python
# REVIEW: Stage variable "{var_name}" may contain unconverted BASIC expression.
# DSX expression: {expression}
```

### D-STAGEVAR-STATEFUL — new cell (CRITICAL)

```python
# COMMAND ----------
# CRITICAL REVIEW: STATEFUL stage variable "{var_name}" — stage: "{stage_name}"
# InitialValue = {initial_value}  |  Depends on: {depends_on_vars}
# DSX expression: {expression}
#
# This variable RETAINS ITS VALUE ACROSS ROWS in DataStage (row-stateful).
# A simple .withColumn() recomputes per row — it does NOT replicate this behavior.
# Lakebridge likely generated incorrect PySpark for this variable.
#
# Common fix patterns:
#   Running flag / accumulator → Window function with cumulative sum
#   Carry-forward (previous row value) → F.lag() over ordered Window
#   Complex row state → consider mapPartitions (preserves partition-level state)
#
# REVIEW: identify the correct stateful pattern and implement before running in production.
# Incorrect implementation will produce WRONG RESULTS SILENTLY.
```

### D-FILTER — inline comment

```python
# REVIEW: DSX filter "{stage_name}" constraint: {constraint}
# Verify .filter() / .where() above implements this exact condition.
```

### D-LOOKUP-FAIL — inline comment

```python
# REVIEW: DSX lookup "{stage_name}" LookupFail=reject — verify reject-path handling exists below.
```

### D-JOIN-TYPE — inline comment

```python
# REVIEW: DSX join type is "{join_type}" — verify .join(..., how="{normalized_how}") above matches.
```

### D-SORT-KEY — inline comment

```python
# REVIEW: DSX sort "{stage_name}" keys: {list with ASC/DESC directions} — verify .orderBy() above matches.
```

### D-CHECKSUM — inline comment

```python
# REVIEW: DSX checksum "{stage_name}" — columns: {list}, algorithm: {algorithm}
# Verify F.md5(F.concat_ws(...)) above uses the correct columns in the correct order.
```

### D-SWITCH — new cell per missing output condition

```python
# COMMAND ----------
# REVIEW: DSX switch "{stage_name}" output "{output_name}" routing condition: {condition}
# Verify a .filter() implementing this condition exists for the "{output_name}" output link.
```

### D-MERGE — inline comment

```python
# REVIEW: DSX merge "{stage_name}" key columns: {list} — verify merge/update logic above is complete.
```

### D-DIFFERENCE — inline comment

```python
# REVIEW: DSX difference "{stage_name}" keys: {list}
# Verify .subtract() or anti-join above uses the correct key columns.
```

### D-MODIFY — inline comment

```python
# REVIEW: DSX modify "{stage_name}" expected output columns: {list with rename/drop annotations}
# Verify column renames, drops, and reordering above match DSX.
```

### D-COL-EXPORT — inline comment

```python
# REVIEW: DSX ColumnExport "{stage_name}" — delimiter: "{delimiter}", columns in order: {list}
# Verify F.concat_ws() above uses the correct delimiter and column order.
```

### D-COL-IMPORT — inline comment

```python
# REVIEW: DSX ColumnImport "{stage_name}" — delimiter: "{delimiter}", target columns in order: {list}
# Verify F.split() and element extraction above match DSX column order.
```

### D-PIVOT — inline comment

```python
# REVIEW: DSX pivot "{stage_name}" — key: {pivot_key}, values: {list}, agg: {agg_function}({agg_col})
# Verify .groupBy().pivot().agg() above matches DSX configuration.
```

### D-REMDUP — inline comment

```python
# REVIEW: DSX RemDup "{stage_name}" key columns: {list}
# Verify .dropDuplicates() above uses the correct key columns.
```

### D-SURROGATE — inline comment

```python
# REVIEW: DSX SurrogateKeyGenerator "{stage_name}" — key: {key_column}, start: {start_value}, increment: {increment}
# Verify key generation logic above matches these values.
```

### D-FUNNEL-COUNT — inline comment

```python
# REVIEW: DSX funnel "{stage_name}" has {n} input links — verify union() / unionAll() above includes all {n}.
```

### D-COPY-COUNT — inline comment

```python
# REVIEW: DSX copy "{stage_name}" replicates to {n} outputs — verify {df_var} is used in {n} downstream paths.
```

### D-PEEK — inline comment

```python
# REVIEW: DSX PxPeek stage "{stage_name}" is debug row logging — remove or comment out before production.
```

### D-ROWGEN — inline comment

```python
# REVIEW: DSX PxRowGenerator stage "{stage_name}" generates test data.
# This stage should NOT exist in a production pipeline. Verify whether this cell should be replaced with a real source read.
```

### D-TAIL — inline comment

```python
# REVIEW: DSX PxTail stage "{stage_name}" returns last {n} rows.
# Verify implementation above uses .orderBy(desc).limit({n}) or equivalent.
```

### D-TERA-INSERT — column-ordered select before write

When WriteMode=0 and `insert_columns` is non-empty: emit a new cell immediately before the existing `.write.saveAsTable()` cell. Do NOT replace the write cell — only add the select.

Emit one `.select()` line per column in `insert_columns`, in DSX-defined order. Use actual column names from the extracted list — no placeholders.

Example output for `insert_columns = ["customer_id", "order_date", "amount"]`:
```python
# COMMAND ----------
# DSX INSERT column mapping — TeradataConnectorPX stage: {stage_name}, WriteMode=0
# DSX defines explicit column order — selecting before write to match target schema.
# REVIEW: verify this column list matches the target Delta table schema exactly before running.
{df_var} = {df_var}.select(
    "customer_id",
    "order_date",
    "amount",
)
```

Fill `{df_var}` from the DataFrame variable in the write cell (never rename it).
Fill column names from `dsx_table_map[stage_name]["insert_columns"]` in order.

---

### D-TERA-UPDATE — replace generic write with DSX-derived column-level merge

When WriteMode=1 and notebook does not implement the `UpdateStatement`:

**SET value translation rules — apply per entry in `update_set_columns`:**

| value_type | DSX example | Emit |
|---|---|---|
| `col_ref` | `SET DATA_VALD_END_TS = ORCHESTRATE.DATA_VALD_END_TS` | `"DATA_VALD_END_TS": F.col("s.DATA_VALD_END_TS")` |
| `literal_string` | `SET REC_STAT_CD = 'D'` | `"REC_STAT_CD": F.lit("D")` |
| `literal_number` | `SET COUNT = 1` | `"COUNT": F.lit(1)` |
| `sql_expr` | `SET LST_CHNG_TS = CURRENT_TIMESTAMP` or `SET col = (CASE WHEN ...)` | `"LST_CHNG_TS": F.expr("CURRENT_TIMESTAMP")` |

For CASE WHEN expressions: replace `ORCHESTRATE.col` with `s.col` and unqualified `col` with `t.col` inside the expression string. Example:
- DSX: `(CASE WHEN REC_STAT_CD='D' THEN LST_CHNG_TS ELSE ORCHESTRATE.LST_CHNG_TS END)`
- Emit: `F.expr("CASE WHEN t.REC_STAT_CD='D' THEN t.LST_CHNG_TS ELSE s.LST_CHNG_TS END")`

**Merge condition:** built from `update_join_keys` + `update_filter_conditions`, joined with ` AND `. Render as a literal string — never leave as a Python list comprehension.
- Join condition: `t.col = s.col` (one per entry in `update_join_keys`)
- Filter condition: `t.col = 'literal'` (use rendered strings from `update_filter_conditions`)

**Output cell — substitute all actual extracted values. No `{placeholder}` strings in the emitted code:**

```python
# COMMAND ----------
# DSX UPDATE — TeradataConnectorPX stage: {stage_name}, WriteMode=1
# UpdateStatement: {original_update_statement}
# Target: {resolved_table_var}  {"(mark-back: updates source_table)" if is_markback}
# Ensure Cell 2 imports: from delta.tables import DeltaTable
# REVIEW: DSX-derived update merge — verify all column mappings and merge condition before running
{table_var}_dt = DeltaTable.forName(spark, {resolved_table_var})
{table_var}_dt.alias("t").merge(
    {input_df}.alias("s"),
    "t.PARTY_ID = s.PARTY_ID AND t.DATA_VALD_END_TS = '9999-12-31 23:59:59'"    # join key + target filter from WhereClause
).whenMatchedUpdate(set={
    "DATA_VALD_END_TS": F.col("s.DATA_VALD_END_TS"),                                          # ORCHESTRATE.col → col_ref
    "LST_CHNG_TS": F.expr("CASE WHEN t.REC_STAT_CD='D' THEN t.LST_CHNG_TS ELSE s.LST_CHNG_TS END"),  # CASE WHEN → sql_expr
    "REC_STAT_CD": F.expr("CASE WHEN t.REC_STAT_CD='D' THEN t.REC_STAT_CD ELSE 'H' END"),             # CASE WHEN → sql_expr
}).execute()
```

The example above is derived from the real DSX UpdateStatement:
```sql
UPDATE #$TERA_ENT_TABLE_DATABASE#.PTY_ACCT
SET DATA_VALD_END_TS=ORCHESTRATE.DATA_VALD_END_TS,
    LST_CHNG_TS=(CASE WHEN REC_STAT_CD='D' THEN LST_CHNG_TS ELSE ORCHESTRATE.LST_CHNG_TS END),
    REC_STAT_CD=(CASE WHEN REC_STAT_CD='D' THEN REC_STAT_CD ELSE 'H' END)
WHERE PARTY_ID=ORCHESTRATE.PARTY_ID AND DATA_VALD_END_TS='9999-12-31 23:59:59'
```

Emit one `set` entry per row in `update_set_columns`. Never leave `{SET_col}`, `{SET_value}`, or `{key_col}` in the output.

---

### D-TERA-UPSERT — replace generic write with DSX-derived merge-upsert

When WriteMode=2 and notebook does not implement a keyed DeltaTable merge:

**Merge condition:** join all `upsert_key_columns` with ` AND ` — render the actual string using real column names, not a Python list comprehension.

**Output cell — substitute all actual values. No `{placeholder}` strings in the emitted code:**

```python
# COMMAND ----------
# DSX UPSERT — TeradataConnectorPX stage: {stage_name}, WriteMode=2
# Upsert key columns: key_col1, key_col2    # rendered from upsert_key_columns
# Target: {resolved_table_var}
# Ensure Cell 2 imports: from delta.tables import DeltaTable
# REVIEW: DSX-derived merge-upsert — verify key columns match DSX definition before running
{table_var}_dt = DeltaTable.forName(spark, {resolved_table_var})
{table_var}_dt.alias("t").merge(
    {input_df}.alias("s"),
    "t.key_col1 = s.key_col1 AND t.key_col2 = s.key_col2"    # rendered from upsert_key_columns
).whenMatchedUpdateAll(
).whenNotMatchedInsertAll(
).execute()
```

Fill `{table_var}` from the DataFrame variable prefix in the write cell.
Render the merge condition string from `dsx_table_map[stage_name]["upsert_key_columns"]` — emit actual column names separated by ` AND `, never a Python list comprehension in the output.

---

### D-TERA-DELETE — replace generic write with DSX-derived delete merge

When WriteMode=3 and notebook has no `whenMatchedDelete()`:

**Merge condition:** join all `delete_key_columns` with ` AND ` — render actual column names.

**Output cell — substitute all actual values. No `{placeholder}` strings in the emitted code:**

```python
# COMMAND ----------
# DSX DELETE — TeradataConnectorPX stage: {stage_name}, WriteMode=3
# DeleteStatement: {original_delete_statement}
# Target: {resolved_table_var}
# Ensure Cell 2 imports: from delta.tables import DeltaTable
# REVIEW: DSX-derived delete merge — verify delete condition before running. Deletes are irreversible.
{table_var}_dt = DeltaTable.forName(spark, {resolved_table_var})
{table_var}_dt.alias("t").merge(
    {input_df}.alias("s"),
    "t.key_col1 = s.key_col1 AND t.key_col2 = s.key_col2"    # rendered from delete_key_columns
).whenMatchedDelete(
).execute()
```

Fill `{table_var}` from the DataFrame variable prefix in the write cell.
Render the merge condition string from `dsx_table_map[stage_name]["delete_key_columns"]`.

---

### D-TERA-TARGET — inline comment (mark-back misidentified as separate target)

```python
# REVIEW: DSX target is {dsx_table_reference} — this resolves to source_table (mark-back pattern).
# This stage updates the SOURCE staging table, not a separate target. Do NOT write to target_table.
# Remove target_table widget if it exists only for this stage.
```

### D-TERA-TABLE — inline comment (table name mismatch)

```python
# REVIEW: DSX XMLProperties table reference is "{dsx_table_reference}" — resolves to "{resolved_name}".
# Notebook widget defaultValue is "{notebook_default}" — verify these point to the same table.
```

### D-TERA-CAST — new cell before target write

When `type_cast_map` is non-empty for a target stage and the write cell has no `.cast()` calls:

`type_cast_map` was built from the reject output pin's `<Collection Name="Columns" Type="OutputColumn">` — those are the actual columns flowing into the Teradata target table (see Step 1 extraction path).

Emit one new `# COMMAND ----------` cell immediately before the `saveAsTable()` cell.
List only columns present in `type_cast_map` (DECIMAL, INTEGER, SMALLINT, BIGINT, DATE, TIMESTAMP, TIME — never CHAR/VARCHAR).
Emit one `.withColumn()` line per column — use actual column names from `type_cast_map`. No `{col_name}` placeholders in the output.

```python
# COMMAND ----------
# DSX TYPE CASTS — TeradataConnectorPX stage: {stage_name}
# Derived from DSX SqlType: DECIMAL → decimal(p,s) | INTEGER → int | SMALLINT → smallint | BIGINT → bigint | DATE → date | TIMESTAMP → timestamp | TIME → HH:mm:ss via F.date_format()
# REVIEW: verify precision/scale for DECIMAL and target Delta schema for all types before running.
# TIME columns: F.date_format() is used — NOT .cast("string"). .cast() on TimestampType produces full datetime, not "HH:mm:ss".
# Remove any column already cast upstream.
{df_var} = (
    {df_var}
    .withColumn("actual_col_name", F.col("actual_col_name").cast("decimal(18,4)"))   # DECIMAL — use actual col and precision
    .withColumn("actual_col_name", F.col("actual_col_name").cast("int"))             # INTEGER
    .withColumn("actual_col_name", F.date_format(F.col("actual_col_name"), "HH:mm:ss"))  # TIME — use F.date_format, not .cast()
)
```

Fill `{df_var}` from the DataFrame variable in the write cell (never rename it).
For each entry in `type_cast_map`: emit one `.withColumn()` line using the actual column name and cast string.
For `cast_type = "time_hms"`: emit the `F.date_format()` line, not `.cast()`.

### D-PARAM — inline comment in parameters cell

```python
# REVIEW: DSX parameter "{param_name}" (default="{default_value}") — verify widget declaration exists above.
```
