# Group D Patch Templates — DataStage Notebook Standardizer
# Version: 2026-04-22
# Load when DSX flag is present (dsx_gaps non-empty in migration_state/{stem}_state.json
# OR DSX GAP REPORT present in conversation context).
# Read fully before applying any Group D fix.
#
# SYNC CONSTRAINT: This file is the standardizer-facing copy of
# databricks-pipeline-advisor/references/dsx-parse-rules.md SECTION 7.
# Any change to Section 7 of dsx-parse-rules.md MUST also be applied here.

---

## Constraints — apply to every patch

- Always use the actual DataFrame variable name from the notebook traceability block — never hardcode
- Always use `F.` prefix for all PySpark functions
- New cell patches (D-CDC-EXEMPT, D-TRANSFORM-CONSTRAINT, D-TRANSFORM-CAST, D-STAGEVAR-STATEFUL, D-SWITCH, D-TERA-INSERT, D-TERA-UPDATE, D-TERA-UPSERT, D-TERA-DELETE, D-TERA-CAST):
  inject as new `# COMMAND ----------` block at the correct position
- All other patches: inline `# REVIEW:` comment in the relevant existing cell
- Never rename DataFrame variables or move traceability block comments
- Substitute ALL placeholder values (`{stage_name}`, `{df_var}`, etc.) with actual values from the gap detail — never leave placeholders in the emitted code

---

### D-CDC-EXEMPT — new cell before target write

```python
# COMMAND ----------
# DSX EXEMPT COLUMNS — PxChangeCapture "dropvalue", stage: {stage_name}
# Rows where ONLY these columns changed → NO CHANGE in DataStage (not treated as an update).
# Key columns    : {comma-separated key_columns}
# Exempt columns : {comma-separated exempt_columns}
#
# REVIEW: implement exempt-column filtering before the target write below.
# Example — adjust column prefix conventions to match your CDC cell:
#   _exempt = [{quoted list of exempt col names}]
#   _key    = [{quoted list of key col names}]
#   _compare_cols = [c for c in {df_var}.columns if c not in _exempt + _key]
#   {df_var} = {df_var}.filter(
#       F.exists(F.array(*[F.col(f"before_{c}") != F.col(f"after_{c}") for c in _compare_cols]),
#                lambda x: x))
# REVIEW: verify column prefix conventions and exempt column list before running
```

### D-CDC-KEY — inline comment

```python
# REVIEW: DSX CDC key columns: {comma-separated list} — verify these are the join/comparison keys above.
```

### D-AGG-KEY / D-AGG-EXPR — inline comment

```python
# REVIEW: DSX aggregator "{stage_name}" group keys: {list} — verify .groupBy() is complete
# REVIEW: DSX aggregate expressions: {list} — verify .agg() is complete
```

### D-TRANSFORM-CONSTRAINT — new cell

```python
# COMMAND ----------
# REVIEW: DSX transformer output "{link_name}" routing constraint: {constraint_expression}
# Verify a .filter() implementing this condition routes rows to the "{link_name}" output.
```

### D-TRANSFORM-DERIVATION — inline comment

```python
# REVIEW: DSX derivation for {col_name}: {expression}
# Verify the .withColumn() above correctly converts this BASIC expression to PySpark.
```

### D-TRANSFORM-CAST — new cell immediately after the transformer cell

When `output_column_types` is non-empty and the transformer cell has no `.cast()` calls:

Build a merged type map by flattening all output pins' `output_column_types` dicts:
- Same column, same cast across pins → deduplicate (emit once)
- Same column, different cast across pins → emit with a `# REVIEW: type conflict` comment listing both types
- The merged map is applied to the main transformer DataFrame — one cast cell covers all downstream pin paths

Emit one `.withColumn()` line per column in the merged map. No `{col_name}` placeholders in the output — use actual column names.

```python
# COMMAND ----------
# DSX TRANSFORMER TYPE CASTS — TransformerStage: {stage_name}
# Types derived from DSX output pin column definitions — applied once, shared by all downstream paths.
# Derived from DSX SqlType: DECIMAL -> decimal(p,s) | INTEGER -> int | SMALLINT -> smallint | BIGINT -> bigint | DATE -> date | TIMESTAMP -> timestamp | TIME -> HH:mm:ss via F.date_format()
# REVIEW: verify precision/scale for DECIMAL and cast types before running.
# TIME columns: F.date_format() is used — NOT .cast("string"). .cast() on TimestampType produces full datetime, not "HH:mm:ss".
{df_var} = (
    {df_var}
    .withColumn("PARTY_ID",         F.col("PARTY_ID").cast("decimal(22,0)"))        # DECIMAL
    .withColumn("ISO_CTRY_ID",      F.col("ISO_CTRY_ID").cast("decimal(18,0)"))     # DECIMAL
    .withColumn("DLR_CORE_EFF_DTE", F.col("DLR_CORE_EFF_DTE").cast("timestamp"))   # TIMESTAMP
    .withColumn("SERIAL_KEY",       F.col("SERIAL_KEY").cast("int"))                # INTEGER
    .withColumn("ACCT_EFF_DTE",     F.col("ACCT_EFF_DTE").cast("date"))             # DATE
    # one .withColumn() per column in merged type map — replace example lines with actual columns
)
```

Fill `{df_var}` from the DataFrame variable produced by the transformer cell.
For `cast_type = "time_hms"`: emit `F.date_format(F.col("col_name"), "HH:mm:ss")` instead of `.cast()`.

---

### D-STAGEVAR-MISSING — inline comment in transformer cell

```python
# REVIEW: DSX stage variable "{var_name}" missing from this cell.
# Expected: .withColumn("{var_name}", {converted_expression})
# DSX expression (BASIC): {expression}
```

### D-STAGEVAR-EXPR — inline comment on the .withColumn()

```python
# REVIEW: Stage variable "{var_name}" may contain unconverted BASIC expression.
# DSX expression: {expression}
```

### D-STAGEVAR-STATEFUL — new cell (CRITICAL)

```python
# COMMAND ----------
# CRITICAL REVIEW: STATEFUL stage variable "{var_name}" — stage: "{stage_name}"
# InitialValue = {initial_value}  |  Depends on: {depends_on_vars}
# DSX expression: {expression}
#
# This variable RETAINS ITS VALUE ACROSS ROWS in DataStage (row-stateful).
# A simple .withColumn() recomputes per row — it does NOT replicate this behavior.
# Lakebridge likely generated incorrect PySpark for this variable.
#
# Common fix patterns:
#   Running flag / accumulator → Window function with cumulative sum
#   Carry-forward (previous row value) → F.lag() over ordered Window
#   Complex row state → consider mapPartitions (preserves partition-level state)
#
# REVIEW: identify the correct stateful pattern and implement before running in production.
# Incorrect implementation will produce WRONG RESULTS SILENTLY.
```

### D-FILTER — inline comment

```python
# REVIEW: DSX filter "{stage_name}" constraint: {constraint}
# Verify .filter() / .where() above implements this exact condition.
```

### D-LOOKUP-FAIL — inline comment

```python
# REVIEW: DSX lookup "{stage_name}" LookupFail=reject — verify reject-path handling exists below.
```

### D-JOIN-TYPE — inline comment

```python
# REVIEW: DSX join type is "{join_type}" — verify .join(..., how="{normalized_how}") above matches.
```

### D-SORT-KEY — inline comment

```python
# REVIEW: DSX sort "{stage_name}" keys: {list with ASC/DESC directions} — verify .orderBy() above matches.
```

### D-CHECKSUM — inline comment

```python
# REVIEW: DSX checksum "{stage_name}" — columns: {list}, algorithm: {algorithm}
# Verify F.md5(F.concat_ws(...)) above uses the correct columns in the correct order.
```

### D-SWITCH — new cell per missing output condition

```python
# COMMAND ----------
# REVIEW: DSX switch "{stage_name}" output "{output_name}" routing condition: {condition}
# Verify a .filter() implementing this condition exists for the "{output_name}" output link.
```

### D-MERGE — inline comment

```python
# REVIEW: DSX merge "{stage_name}" key columns: {list} — verify merge/update logic above is complete.
```

### D-DIFFERENCE — inline comment

```python
# REVIEW: DSX difference "{stage_name}" keys: {list}
# Verify .subtract() or anti-join above uses the correct key columns.
```

### D-MODIFY — inline comment

```python
# REVIEW: DSX modify "{stage_name}" expected output columns: {list with rename/drop annotations}
# Verify column renames, drops, and reordering above match DSX.
```

### D-COL-EXPORT — inline comment

```python
# REVIEW: DSX ColumnExport "{stage_name}" — delimiter: "{delimiter}", columns in order: {list}
# Verify F.concat_ws() above uses the correct delimiter and column order.
```

### D-COL-IMPORT — inline comment

```python
# REVIEW: DSX ColumnImport "{stage_name}" — delimiter: "{delimiter}", target columns in order: {list}
# Verify F.split() and element extraction above match DSX column order.
```

### D-PIVOT — inline comment

```python
# REVIEW: DSX pivot "{stage_name}" — key: {pivot_key}, values: {list}, agg: {agg_function}({agg_col})
# Verify .groupBy().pivot().agg() above matches DSX configuration.
```

### D-REMDUP — inline comment

```python
# REVIEW: DSX RemDup "{stage_name}" key columns: {list}
# Verify .dropDuplicates() above uses the correct key columns.
```

### D-SURROGATE — inline comment

```python
# REVIEW: DSX SurrogateKeyGenerator "{stage_name}" — key: {key_column}, start: {start_value}, increment: {increment}
# Verify key generation logic above matches these values.
```

### D-FUNNEL-COUNT — inline comment

```python
# REVIEW: DSX funnel "{stage_name}" has {n} input links — verify union() / unionAll() above includes all {n}.
```

### D-COPY-COUNT — inline comment

```python
# REVIEW: DSX copy "{stage_name}" replicates to {n} outputs — verify {df_var} is used in {n} downstream paths.
```

### D-PEEK — inline comment

```python
# REVIEW: DSX PxPeek stage "{stage_name}" is debug row logging — remove or comment out before production.
```

### D-ROWGEN — inline comment

```python
# REVIEW: DSX PxRowGenerator stage "{stage_name}" generates test data.
# This stage should NOT exist in a production pipeline. Verify whether this cell should be replaced with a real source read.
```

### D-TAIL — inline comment

```python
# REVIEW: DSX PxTail stage "{stage_name}" returns last {n} rows.
# Verify implementation above uses .orderBy(desc).limit({n}) or equivalent.
```

### D-TERA-INSERT — column-ordered select before write

When WriteMode=0 and `insert_columns` is non-empty: emit a new cell immediately before the existing `.write.saveAsTable()` cell.

```python
# COMMAND ----------
# DSX INSERT column mapping — TeradataConnectorPX stage: {stage_name}, WriteMode=0
# DSX defines explicit column order — selecting before write to match target schema.
# REVIEW: verify this column list matches the target Delta table schema exactly before running.
{df_var} = {df_var}.select(
    "customer_id",
    "order_date",
    "amount",
    # replace example lines with actual columns from insert_columns in DSX-defined order
)
```

Fill `{df_var}` from the DataFrame variable in the write cell (never rename it).
Fill column names from `detail["insert_columns"]` in order.

---

### D-TERA-UPDATE — replace generic write with DSX-derived column-level merge

When WriteMode=1 and notebook does not implement the `UpdateStatement`:

**SET value translation rules — apply per entry in `update_set_columns`:**

| value_type | DSX example | Emit |
|---|---|---|
| `col_ref` | `SET DATA_VALD_END_TS = ORCHESTRATE.DATA_VALD_END_TS` | `"DATA_VALD_END_TS": F.col("s.DATA_VALD_END_TS")` |
| `literal_string` | `SET REC_STAT_CD = 'D'` | `"REC_STAT_CD": F.lit("D")` |
| `literal_number` | `SET COUNT = 1` | `"COUNT": F.lit(1)` |
| `sql_expr` | `SET LST_CHNG_TS = CURRENT_TIMESTAMP` | `"LST_CHNG_TS": F.expr("CURRENT_TIMESTAMP")` |

For CASE WHEN: replace `ORCHESTRATE.col` with `s.col`, unqualified `col` in target context with `t.col`.

**Merge condition:** built from `update_join_keys` + `update_filter_conditions`, joined with ` AND `.

```python
# COMMAND ----------
# DSX UPDATE — TeradataConnectorPX stage: {stage_name}, WriteMode=1
# UpdateStatement: {original_update_statement}
# Target: {resolved_table_var}
# Ensure Cell 2 imports: from delta.tables import DeltaTable
# REVIEW: DSX-derived update merge — verify all column mappings and merge condition before running
{table_var}_dt = DeltaTable.forName(spark, {resolved_table_var})
{table_var}_dt.alias("t").merge(
    {input_df}.alias("s"),
    "t.PARTY_ID = s.PARTY_ID AND t.DATA_VALD_END_TS = '9999-12-31 23:59:59'"
).whenMatchedUpdate(set={
    "DATA_VALD_END_TS": F.col("s.DATA_VALD_END_TS"),
    "LST_CHNG_TS": F.expr("CASE WHEN t.REC_STAT_CD='D' THEN t.LST_CHNG_TS ELSE s.LST_CHNG_TS END"),
    "REC_STAT_CD": F.expr("CASE WHEN t.REC_STAT_CD='D' THEN t.REC_STAT_CD ELSE 'H' END"),
}).execute()
```

Emit one `set` entry per row in `detail["update_set_columns"]`. Never leave `{SET_col}`, `{SET_value}`, or `{key_col}` in the output.

---

### D-TERA-UPSERT — replace generic write with DSX-derived merge-upsert

When WriteMode=2 and notebook does not implement a keyed DeltaTable merge:

```python
# COMMAND ----------
# DSX UPSERT — TeradataConnectorPX stage: {stage_name}, WriteMode=2
# Upsert key columns: {rendered from detail["upsert_key_columns"]}
# Target: {resolved_table_var}
# Ensure Cell 2 imports: from delta.tables import DeltaTable
# REVIEW: DSX-derived merge-upsert — verify key columns match DSX definition before running
{table_var}_dt = DeltaTable.forName(spark, {resolved_table_var})
{table_var}_dt.alias("t").merge(
    {input_df}.alias("s"),
    "t.key_col1 = s.key_col1 AND t.key_col2 = s.key_col2"
).whenMatchedUpdateAll(
).whenNotMatchedInsertAll(
).execute()
```

Render the merge condition from `detail["upsert_key_columns"]` — actual column names only, never a Python list comprehension.

---

### D-TERA-DELETE — replace generic write with DSX-derived delete merge

When WriteMode=3 and notebook has no `whenMatchedDelete()`:

```python
# COMMAND ----------
# DSX DELETE — TeradataConnectorPX stage: {stage_name}, WriteMode=3
# DeleteStatement: {original_delete_statement}
# Target: {resolved_table_var}
# Ensure Cell 2 imports: from delta.tables import DeltaTable
# REVIEW: DSX-derived delete merge — verify delete condition before running. Deletes are irreversible.
{table_var}_dt = DeltaTable.forName(spark, {resolved_table_var})
{table_var}_dt.alias("t").merge(
    {input_df}.alias("s"),
    "t.key_col1 = s.key_col1 AND t.key_col2 = s.key_col2"
).whenMatchedDelete(
).execute()
```

Render the merge condition from `detail["delete_key_columns"]`.

---

### D-TERA-TARGET — inline comment (mark-back misidentified as separate target)

```python
# REVIEW: DSX target is {dsx_table_reference} — this resolves to source_table (mark-back pattern).
# This stage updates the SOURCE staging table, not a separate target. Do NOT write to target_table.
# Remove target_table widget if it exists only for this stage.
```

### D-TERA-TABLE — inline comment (table name mismatch)

```python
# REVIEW: DSX XMLProperties table reference is "{dsx_table_reference}" — resolves to "{resolved_name}".
# Notebook widget defaultValue is "{notebook_default}" — verify these point to the same table.
```

### D-TERA-CAST — new cell before target write

When `type_cast_map` is non-empty for a target stage and the write cell has no `.cast()` calls:

**Suppression check:** Build `residual_map` = columns in `detail["residual_map"]` only (columns NOT already cast by D-TRANSFORM-CAST upstream). If `residual_map` is empty → do NOT emit this patch.

```python
# COMMAND ----------
# DSX TYPE CASTS — TeradataConnectorPX stage: {stage_name}
# Derived from DSX SqlType: DECIMAL -> decimal(p,s) | INTEGER -> int | SMALLINT -> smallint | BIGINT -> bigint | DATE -> date | TIMESTAMP -> timestamp | TIME -> HH:mm:ss via F.date_format()
# REVIEW: verify precision/scale for DECIMAL and target Delta schema for all types before running.
# TIME columns: F.date_format() is used — NOT .cast("string"). .cast() on TimestampType produces full datetime, not "HH:mm:ss".
{df_var} = (
    {df_var}
    .withColumn("actual_col_name", F.col("actual_col_name").cast("decimal(18,4)"))
    .withColumn("actual_col_name", F.col("actual_col_name").cast("int"))
    .withColumn("actual_col_name", F.date_format(F.col("actual_col_name"), "HH:mm:ss"))
    # one .withColumn() per column in residual_map — replace example lines with actual columns
)
```

For each entry in `detail["residual_map"]`: emit one `.withColumn()` using actual column name and cast string.
For `cast_type = "time_hms"`: emit `F.date_format()`, not `.cast()`.

### D-PARAM — inline comment in parameters cell

```python
# REVIEW: DSX parameter "{param_name}" (default="{default_value}") — verify widget declaration exists above.
```
