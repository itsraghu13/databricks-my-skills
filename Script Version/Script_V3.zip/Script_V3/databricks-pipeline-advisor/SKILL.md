---
name: databricks-pipeline-advisor
description: >
  Analyzes a folder of Databricks PySpark notebooks to build a dependency
  map, suggest consolidation, and optionally merge approved notebooks into
  one standardized combined notebook. Trigger on: "analyze these notebooks",
  "analyze <folder_name>", "can we merge these", "consolidate this pipeline",
  "what order do these run in", "are there duplicates", "reduce number of
  notebooks", or when a user pastes multiple .py files or a folder listing.
  Analysis phase is always read-only. Merge only runs after explicit approval.
---

# Databricks Pipeline Advisor

Analyze a collection of Databricks notebooks. Show dependency map and
consolidation recommendations. Merge and standardize only after approval.

**Hard rules:**
- Analysis (Steps 1–3) is always read-only — no code generated
- Merge (Steps 4–5) only runs after `merge` command from user
- Never change business logic during merge — structure only
- One combined notebook output for the whole folder

---

## MANDATORY PRE-FLIGHT — execute before reading any notebook

**Trigger: input contains a folder path OR any `.xml` / `.dsx` file.**

**DO NOT read notebook content until this checklist is complete.**

1. List all files in the folder/input.
2. Identify every `.xml` / `.dsx` file present.
3. For EACH XML file — check freshness:
   - `profiles/{stem}_profile.json` exists AND is newer than the XML file → **READ the existing profile. No script run needed.**
   - Profile absent or stale → **EXECUTE THIS COMMAND NOW:**
     ```
     python scripts/extract_dsx.py {xml_path}
     ```
     (If running from project root: `python databricks-pipeline-advisor/scripts/extract_dsx.py {xml_path}`)
     **Immediately after execution: read `profiles/{stem}_profile.json` from the same folder as the XML.**
4. Verify: profile count equals XML file count. If any profile is missing → re-run extractor on the missing file.
5. **ONLY AFTER all profiles are confirmed** → proceed to Step 0.

**No XML files present** → skip this block entirely, proceed to Step 0.

---

## Step 0 — Detect and analyze script (if present)

Before indexing notebooks, check if input contains a shell script
(.ksh / .sh / .bash / starts with #!/bin/ksh or #!/bin/bash).

If script detected:
1. Read `references/script-analysis-rules.md`
2. Classify script type (ORCHESTRATION / PRE-PROCESSING / POST-PROCESSING / MIXED)
3. Extract script profile (source_table, target_table, ds_job_name, data_logic)
4. Map script to notebooks using job ID + content matching
5. Store script profile — use it to enrich notebook profiles in Step 2

If no script detected: skip this step entirely, proceed to Step 0-A.

## Step 0-A — Detect DSX input pattern (detection only — no actions here)

Identify which pattern applies to the DSX input:

- **Pattern A — Paired files**: multiple `.xml` files, each paired to a `.py` by filename stem
- **Pattern B — Single multi-job DSX**: one `.xml` with multiple `<Record Type="JobDefn">` blocks
- **Pattern C — Single job DSX**: one `.xml` with exactly one `<Record Type="JobDefn">`
- **Pattern D — Pre-extracted JSON profile**: `profiles/{stem}_profile.json` already present (MANDATORY PRE-FLIGHT already handled this)

Note which pattern applies. Proceed to Step 0-B.

If no DSX detected: skip Steps 0-A through 0-C entirely, proceed to Step 1.

## Step 0-B — EXECUTE DSX profile extraction

**If Pattern D (profile already read in PRE-FLIGHT):** use that profile as `dsx_profile`, skip to Step 0-C.

**If Pattern A / B / C — profile extraction is REQUIRED before any other work:**

**EXECUTE:** `python scripts/extract_dsx.py {dsx_path}`
(From project root: `python databricks-pipeline-advisor/scripts/extract_dsx.py {dsx_path}`)

**Immediately read** the output `profiles/{stem}_profile.json` from the same folder as the DSX and store as `dsx_profile`.

**If the script fails or is not found** → fall back to manual XML parsing:
1. Read `references/dsx-parse-rules.md` (Sections 1–7)
2. Check DSX file size:
   - **≤ 30K characters** → full parse: iterate every `<Record Type="JobDefn">` and extract all stages directly
   - **> 30K characters** → pre-filter strategy (Section 1 Large DSX File Strategy):
     a. Light pass — extract job names only
     b. Match job names against notebooks (filename stem + traceability block content)
     c. Deep parse matched jobs only — full Section 4 extraction on matched job blocks, skip all others
     d. Add pre-filter header to DSX GAP REPORT: file size, total jobs, matched count, skipped count
3. For each job definition being parsed, extract ALL stage types (Section 4 of parse rules):
   - Job parameters (non-password)
   - CDC stages: stage_name, key_columns, exempt_columns
   - Aggregator stages: stage_name, group_key_columns, aggregate_expressions
   - Transformer stages: stage_name, column derivations, output pin constraints,
     output_column_types (per-pin dict {col_name: cast_str} for castable SqlTypes — same SqlType table used for type_cast_map),
     AND stage variables — stateless (no InitialValue) AND stateful (has InitialValue)
   - Filter stages: stage_name, constraint
   - Lookup stages: stage_name, lookup_fail
   - Join stages: stage_name, join_type, key_columns
   - Sort stages: stage_name, sort_keys with directions
   - Funnel stages: stage_name, input_pin_count
   - Checksum stages: stage_name, checksum_columns, algorithm
   - Switch stages: stage_name, per-output-pin conditions
   - Merge stages: stage_name, key_columns
   - Difference stages: stage_name, key_columns
   - Modify stages: stage_name, column rename/drop spec
   - ColumnExport stages: stage_name, delimiter, column list
   - ColumnImport stages: stage_name, delimiter, target columns
   - Pivot stages: stage_name, pivot_key, values, aggregate
   - RemDup stages: stage_name, key_columns
   - SurrogateKeyGenerator stages: stage_name, key_column, start_value, increment
   - Copy stages: stage_name, output_pin_count
   - Peek / RowGenerator / Tail stages: stage_name (flagged for removal)
   - TeradataConnectorPX stages (two-pass — Section 4W of dsx-parse-rules.md):
     Step 1 (outer XML first): stage_name, context, reject_mappings;
       AND for context=target: read InputPins from stage record → find each CustomInput Record →
       read its Partner property → take last segment after `|` → find that upstream output pin Record →
       extract `<Collection Name="Columns" Type="OutputColumn">` from that upstream pin (TrxOutput or CustomOutput)
       (Name, SqlType, Precision, Scale) → build type_cast_map {col_name → "decimal(p,s)"|"int"|"smallint"|"bigint"|"date"|"timestamp"|"time_hms"}
       for SqlType ∈ {3=DECIMAL, 4=INTEGER, 5=SMALLINT, -5=BIGINT, 9=DATE, 11=TIMESTAMP, 92=TIME}. Complete Step 1 before Step 2.
       TIME columns store sentinel "time_hms" — D-TRANSFORM-CAST and D-TERA-CAST both emit F.date_format(F.col(col), "HH:mm:ss"), not .cast().
     Step 2 (XMLProperties embedded XML): write_mode (0=insert,1=update,2=upsert,3=delete),
       table_reference, update_statement, insert_columns, update_set_columns,
       update_join_keys, update_filter_conditions, upsert_key_columns,
       delete_statement, delete_key_columns, is_markback
       — set is_markback=True when UpdateStatement target resolves to a source table in the same job
       — ORCHESTRATE.col in SET/WHERE → s.col; unqualified col in target context → t.col
       — WhereClause sub-element is authoritative for WHERE parsing (not raw SQL text)
       — full extraction rules in dsx-parse-rules.md Section 4W
   - PxSequentialFile stages: stage_name, context, file_path, file_suffix
     — derive Delta table name as {TARGET_TABLE_NAME}_{STAGE_SUFFIX} for cross-notebook consistency
   After extracting all TeradataConnectorPX and PxSequentialFile stages: build dsx_table_map
   (per-job registry: stage_name → table_reference, context, write_mode, is_markback, set/key columns, type_cast_map).
4. Map each stage to its notebook using the two-step algorithm in Section 5:
   - Pattern A: filename stem match first (step1.xml → step1.py), then content match fallback
   - Patterns B/C: content match only (`# Original DS name: {stage_name}` in traceability blocks)
5. Store as dsx_profile — used in Step 3 (gap cross-reference) and Step 4 (gap report)

## Step 0-C — Verify profiles before proceeding

Before moving to Step 1, confirm ALL of the following:
- [ ] Every `.xml` / `.dsx` file in the input has a corresponding `profiles/{stem}_profile.json`
- [ ] Every profile has been read into memory as `dsx_profile`
- [ ] Profile job count > 0 (non-empty extraction)

**If any check fails** → re-run `python scripts/extract_dsx.py {missing_xml_path}` and read the output.
**DO NOT proceed to Step 1 until all checks pass.**

## Step 1 — Detect input

Accept any of: filenames only, full notebook content, mixed, or a folder path.

**If input was a folder path:** PRE-FLIGHT + Steps 0-A through 0-C already handled DSX extraction.
Now read each `.py` notebook file for full content analysis, then proceed to Step 2.

For filenames only (no folder path, no notebook content): partial analysis only (no source/target detection).

Read `references/analysis-rules.md` for extraction rules and merge signals.

## Step 2 — Index (silent, per notebook)

For each notebook extract:
- `file_name`, `seq_no`, `domain` — from filename pattern
- `sources`, `targets` — from SRC/TGT widgets → spark.read/saveAsTable → traceability comments → filename
- `stage_types` — from `# Node type` traceability comments
- `cell_count`, `converted_on` — from header

If script profile exists from Step 0:
- Override source_table defaultValue with script profile source_table
- Override target_table defaultValue with script profile target_table
- Add ds_job_name to notebook purpose
- Add data_logic items to notebook profile for injection during fix

## Step 2.5 — Table Validation Script

After Step 2 indexing is complete, collect every unique source and target table from all
notebook profiles (deduplicate). Generate and output the following PySpark cell exactly
as shown, with the actual extracted table names filled in:

```python
# TABLE VALIDATION SCRIPT — generated by Databricks Pipeline Advisor
# Run this cell in a Databricks notebook and paste the full printed output back.

import pandas as pd

tables_to_check = [
    # ("ROLE", "notebook_filename", "catalog.schema.table")
    ("SOURCE", "{notebook_name}", "{full_3_part_table_name}"),
    ("TARGET", "{notebook_name}", "{full_3_part_table_name}"),
    # one row per unique table across all notebooks
]

# Dynamically find tier catalogs — avoids hardcoding, keeps search fast
tier_keywords = ["bronze", "silver", "gold", "raw", "landing", "staging"]
all_catalogs  = [c.name for c in spark.catalog.listCatalogs()]
tier_catalogs = [c for c in all_catalogs if any(kw in c.lower() for kw in tier_keywords)]

results = []
for role, notebook, full_name in tables_to_check:
    parts       = full_name.split(".")
    table_name  = parts[-1]
    schema_name = parts[-2] if len(parts) >= 2 else "default"
    found       = spark.catalog.tableExists(full_name)
    suggestion  = None

    if not found:
        for cat in tier_catalogs:
            candidate = f"{cat}.{schema_name}.{table_name}"
            if spark.catalog.tableExists(candidate):
                suggestion = candidate
                break

    results.append({
        "role":       role,
        "notebook":   notebook,
        "expected":   full_name,
        "found":      "YES" if found else "NO",
        "suggestion": suggestion if suggestion else ("—" if found else "NOT FOUND"),
    })

df = pd.DataFrame(results)
print(df.to_string(index=False))
```

After outputting the script, prompt:
```
Run this cell in a Databricks notebook and paste the full printed output below.
Type  skip  to proceed without table validation — all tables will be marked # REVIEW.
```

**If engineer pastes output:** Parse each row. For each table, store:
- `found = YES | NO`
- `suggestion = {3-part path} | — | NOT FOUND`
Attach these to the corresponding table entries in the profile store. Proceed to Step 3.

**If engineer types `skip`:** Mark all tables as `UNVERIFIED`. Proceed to Step 3.

**If table name contains widget variables** (e.g. `{source_catalog}.{source_schema}.{source_table}`
where the actual catalog/schema/table are not yet resolved): mark as `UNVERIFIED` and
exclude from the `tables_to_check` list — do not generate a check for it.

---

## Step 3 — Analyze (silent, across all profiles)

Using all profiles:
1. Build dependency DAG — notebook A depends on B if A's source = B's target
2. Topological sort → execution order + parallel groups
3. Apply merge signals from `references/analysis-rules.md`
4. Detect redundancies (duplicate source reads, same target written by 2+ notebooks)
5. Detect orphans (no detected source or target)
6. Carry each profile's confidence level (HIGH/MEDIUM/LOW from Step 2) into merge candidate scoring — widget-parameterized sources downgrade to MEDIUM; filename-only inference downgrades to LOW
7. **DSX gap cross-reference** (only if dsx_profile exists from Step 0-A):
   Apply every gap detection rule from `references/dsx-parse-rules.md` Section 6
   against the matched notebook cell for each stage in dsx_profile.
   Collect all gaps as a list: gap_id, notebook_filename, stage_name, severity, detail.
   Unmatched stages (not found in any notebook) → note as UNMATCHED, no fix generated.
   CRITICAL gaps (D-STAGEVAR-STATEFUL) are flagged separately for prominence in report.

   **D-TRANSFORM-CAST / D-TERA-CAST ordering (per notebook):**
   Always evaluate D-TRANSFORM-CAST before D-TERA-CAST:
   a. For each TransformerStage in this notebook: flatten all `output_column_types` pins into a single
      `transformer_cast_cols` set (column names only). If the transformer cell has no `.cast()` or
      `F.date_format()` for any of those columns → fire D-TRANSFORM-CAST.
   b. When evaluating D-TERA-CAST for any TeradataConnectorPX target stage in the same notebook:
      build `residual_map = {col: cast for col, cast in type_cast_map.items() if col not in transformer_cast_cols}`.
      - `residual_map` empty → suppress D-TERA-CAST entirely (all columns cast upstream).
      - `residual_map` non-empty → fire D-TERA-CAST for `residual_map` columns only.

## Step 4 — Report

Output this exact structure:

```
DATABRICKS PIPELINE ADVISOR
────────────────────────────────────────────────────────────────────
Notebooks : {n}   Sources : {n}   Targets : {n}
────────────────────────────────────────────────────────────────────

EXECUTION ORDER
  STAGE 1 (parallel): {notebook names}
  STAGE 2 (depends on Stage 1): {notebook names}
  INDEPENDENT: {notebook names}

MERGE CANDIDATES
  MERGE-01 — {type}  [MERGE | KEEP SEPARATE | REVIEW BEFORE MERGE]  [{HIGH|MEDIUM|LOW} confidence]
    Notebooks : {list}
    Reason    : {one sentence}
    Scoring   : {✓ or ✗ for each of the 7 factors — see analysis-rules.md}
    Decision  : MERGE | KEEP SEPARATE | REVIEW BEFORE MERGE
    Risk      : {LOW | MEDIUM | HIGH}

REDUNDANCIES
  RED-01 — {type}: {description}  [{LOW|MEDIUM|HIGH} severity}]

ORPHANS
  {filename} — {reason no dependencies detected}

TABLE STATUS
  ────────────────────────────────────────────────────────────────────
  Role    Notebook            Expected                              Found  Suggestion
  ────────────────────────────────────────────────────────────────────
  SOURCE  Step01_Unload.py    dev_edf_bronze.default.orders         YES    —
  TARGET  Step03_CDC.py       dev_edf_silver.default.order_sum      NO     prod_edf_silver.default.order_sum
  ────────────────────────────────────────────────────────────────────
  ⚠  {n} table(s) not found — suggestion available, defaultValue will be corrected in output.
  ⚠  {n} table(s) not found with no suggestion — will be marked # REVIEW in output.

INVENTORY
  File                     Cells  Sources  Targets  Stage Types
  ──────────────────────────────────────────────────────────────
  {filename}               {n}    {n}      {n}      {list}
  ──────────────────────────────────────────────────────────
  {If total notebooks > 20: show first 20 rows only, then: "... and {n} more — type  show inventory  for full list."}
  {If total notebooks ≤ 20: show all rows, omit the truncation line.}

DSX TABLE MAP
  ────────────────────────────────────────────────────────────────────
  {If no DSX was provided OR dsx_table_map is empty: omit this entire section.}
  {If dsx_table_map populated:}
  Stage                         Context   WriteMode    Table Reference                  Mark-back
  ────────────────────────────────────────────────────────────────────
  {stage_name}                  target    INSERT(0)    #$TERA_ENT_TABLE_DATABASE#.tbl   —
  {stage_name}                  target    UPDATE(1)    #$TERA_STG_TABLE_DATABASE#.tbl   YES
  {stage_name}                  target    UPSERT(2)    #$TERA_ENT_TABLE_DATABASE#.tbl   —
  {stage_name}                  target    DELETE(3)    #$TERA_ENT_TABLE_DATABASE#.tbl   —
  ────────────────────────────────────────────────────────────────────
  {Mark-back entries flagged YES: these stages update their source table — map to source_table widget, not target_table}
  {UPDATE entries: update_join_keys + update_filter_conditions form the merge condition; update_set_columns with value_type drive the set dict}
  {UPSERT entries: upsert_key_columns shown in D-TERA-UPSERT gap detail — keyed DeltaTable merge required}
  {DELETE entries: delete_key_columns form the merge condition for whenMatchedDelete()}

DSX GAP REPORT
  ────────────────────────────────────────────────────────────────────
  {If no DSX was provided: omit this entire section.}
  {If DSX provided and zero gaps: "All {n} DSX stages correctly represented in notebooks."}
  {If DSX provided and gaps found:}
  DSX file : {filename}   Stages analyzed : {n}   Gaps : {n}
    CRITICAL : {n}   HIGH : {n}   MEDIUM : {n}   LOW : {n}
  ────────────────────────────────────────────────────────────────────
  {List CRITICAL items first, then HIGH, then MEDIUM, then LOW}
  GAP-001  D-STAGEVAR-STATEFUL  {notebook_filename}  CRITICAL  REVIEW
    Stage  : {stage_name} (TransformerStage)
    Var    : {var_name}  InitialValue: {initial_value}
    Detail : Row-stateful variable — simple .withColumn() produces wrong results
    DSX    : {expression}

  GAP-002  D-CDC-EXEMPT  {notebook_filename}  HIGH  REVIEW
    Stage   : {stage_name} (PxChangeCapture)
    Detail  : {n} exempt columns absent from change detection logic
    Columns : {comma-separated list}

  {... one block per gap found, using same format ...}
  ────────────────────────────────────────────────────────────────────
  {Always show D-PEEK and D-ROWGEN even if LOW severity — must be resolved before production.}
  {Unmatched stages: "UNMATCHED: {stage_name} — '# Original DS name: {stage_name}' not found in any notebook"}

SUMMARY
  Merge candidates  : {n}
  Redundancies      : {n}
  Orphans           : {n}
  Execution stages  : {n}
  DSX gaps          : {n CRITICAL / n HIGH / n MEDIUM / n LOW | "N/A — no DSX provided"}
────────────────────────────────────────────────────────────────────
{CONTEXT-AWARE COMMANDS — see rules below}
────────────────────────────────────────────────────────────────────
```

Confidence levels: HIGH = SRC/TGT widgets found, MEDIUM = spark.read/saveAsTable found, LOW = filename only.

**TABLE STATUS rendering rules:**
- All tables found → replace section body with: `All {n} tables verified in Unity Catalog.`
- Step 2.5 was skipped → replace section body with: `Table validation skipped — all tables marked # REVIEW in output.`
- Mix of found/not-found → show the full table as above; include only the ⚠ lines that apply (omit lines with n=0)
- UNVERIFIED tables (widget variables, unresolvable at analysis time) → omit from table, note count: `{n} table(s) use widget variables — verified at runtime by RuntimeError checks in Cell 6.`

**Context-aware commands rule — choose the right block based on analysis result:**

If ALL merge candidates are KEEP SEPARATE:
```
Commands:
  @datastage-notebook-standardizer fix all              → standardize all {n} notebooks
  @datastage-notebook-standardizer fix Step01,Step03    → standardize specific notebooks only
  report only                                           → stop here, no changes made
```

If at least one merge candidate is MERGE:
```
Commands:
  merge all                                             → merge all MERGE candidates + fix kept-separate notebooks
  merge MERGE-01                                        → merge specific group only + fix kept-separate notebooks
  skip MERGE-02                                         → exclude group from merge, fix it individually instead
  @datastage-notebook-standardizer fix all              → skip merging, standardize all notebooks individually
  report only                                           → stop here, no changes made
```

If zero merge candidates found (no dependency patterns detected):
```
Commands:
  @datastage-notebook-standardizer fix all              → standardize all {n} notebooks
  @datastage-notebook-standardizer fix Step01           → standardize one specific notebook
  report only                                           → stop here, no changes made
```

**Never show `merge all` or `merge MERGE-xx` commands when all candidates are KEEP SEPARATE.**
**Always show `@datastage-notebook-standardizer fix all` as an option — it is always valid regardless of merge outcome.**
**Always show `report only` as the last option.**
**The `@datastage-notebook-standardizer` prefix is required — this routes the fix command to the
canonical skill. Do NOT show `fix all` as a bare command without the prefix.**

Also add to SUMMARY section when all are KEEP SEPARATE:
```
RECOMMENDED NEXT STEP:
  All notebooks should remain separate.
  Copy and run: @datastage-notebook-standardizer fix all
  This routes to the standardizer skill which will fix each notebook in sequence.
  Use this execution order for your Databricks Workflow:
  {repeat the execution order from the EXECUTION ORDER section}
```

Also add to SUMMARY section when result is mixed (some MERGE, some KEEP SEPARATE):
```
RECOMMENDED NEXT STEP:
  Type a merge command above to merge and fix in one pass (runs within this skill).
  Or copy and run: @datastage-notebook-standardizer fix all  to skip merging and standardize all individually.
```

## Step 5 — Execute (after command)

**Content guard — check before any merge or fix:**
If notebook content was NOT provided in Step 1 for any notebook named in the command
(i.e. only filenames were given, no actual code), stop immediately and respond:
```
Cannot proceed — notebook content required.
Paste the full content of these notebooks to continue:
  {list each notebook whose content is missing}
```
Do not attempt to generate, infer, or fabricate notebook content.

**Table correction rules — apply to every table widget in every output notebook:**

For each `source_table`, `target_table`, `source_table1`, `source_table2`, etc. widget:

| Validation status | Action |
|---|---|
| `found = YES` | Use expected path as-is. No change. |
| `found = NO`, suggestion exists | Replace widget `defaultValue` with suggestion. Add comment: `# Table corrected: {expected} not found — updated to {suggestion} (from validation check)` |
| `found = NO`, no suggestion | Keep original defaultValue. Add: `# REVIEW: {table} — not found in Unity Catalog and no suggestion available. Verify before running.` |
| `UNVERIFIED` (widget variable or skipped) | Keep original defaultValue. The `RuntimeError` check in Cell 6 will catch this at runtime. |

These corrections apply to both the `merge` path and the `fix all` path.

**DSX gap patch rules — apply after table corrections, for every notebook in the fix/merge pass:**

If dsx_profile exists and has gaps for a notebook:
1. Apply all Group D patches from `references/dsx-parse-rules.md` Section 7 to that notebook
2. Ordering: inject CRITICAL patches first (D-STAGEVAR-STATEFUL), then HIGH, then MEDIUM, then LOW
3. New-cell patches (D-CDC-EXEMPT, D-TRANSFORM-CONSTRAINT, D-TRANSFORM-CAST, D-STAGEVAR-STATEFUL, D-SWITCH, D-TERA-UPDATE, D-TERA-CAST):
   insert as new `# COMMAND ----------` blocks at the correct position (D-TRANSFORM-CAST goes immediately
   after the transformer cell; D-TERA-CAST and others go before the target write cell)
4. Inline patches: add `# REVIEW:` comment to the relevant line in the existing cell
5. Always use the actual DataFrame variable name from the notebook's traceability block —
   never hardcode a variable name
6. All Group D fixes are REVIEW (never AUTO) — count them separately in fix summary:
   `D-group: {n} (all REVIEW)`

**If command is `show inventory`:**
Output the full INVENTORY table for all notebooks — no truncation, all rows shown.
Do not re-run analysis. Serve from the profiles already built in Step 2.

**If command is `report only`:**
No code is generated. The Step 4 report is the complete and final output for this session.

**If command is `skip MERGE-xx`:**
Remove the named group(s) from the merge queue. Each skipped group's notebooks will be fixed
individually (same as kept-separate notebooks) rather than merged. Multiple skips are cumulative:
`skip MERGE-02` then `merge all` merges everything except MERGE-02. After processing skips,
re-evaluate the remaining command (`merge all`, `merge MERGE-01`, etc.) and continue with Step 5.

**If command is `merge ...`:**
Read `references/fix-rules-embedded.md` and assemble merged notebook.
See assembly order below.

**If command is bare `fix all` or `fix Step01,Step03` (without `@datastage-notebook-standardizer` prefix):**
The canonical path is `@datastage-notebook-standardizer fix all` — if the user typed the bare
command, remind them: "For best results use: `@datastage-notebook-standardizer fix all` — this
routes to the canonical standardizer skill. Continuing with embedded rules as fallback."
Then run standardizer rules from `references/fix-rules-embedded.md` on each specified notebook
individually. **One notebook per response — never output two notebooks in the same response.**

Phase 1 — scan all notebooks first, output fix summary only (no notebook code):
```
BATCH SCAN — {n} notebooks queued
────────────────────────────────────────────────────────────────────
Step01_Unload_ENR005.py  : {n} issues  (AUTO: {n}  REVIEW: {n})
Step03_Ins_SSD_TYP.py    : {n} issues  (AUTO: {n}  REVIEW: {n})
────────────────────────────────────────────────────────────────────
Total fixes : {n}   AUTO: {n}   REVIEW: {n}
────────────────────────────────────────────────────────────────────
Type  approve all  to begin. Notebooks will be output one at a time.
```

Phase 2 — one fixed notebook per write, saved to `./fixed/`:
1. Use the Write tool to save FIRST notebook to `./fixed/{filename}` (always relative to CWD — create folder if needed).
2. Confirm with header: `── Saved 1/{n}: fixed/Step01_Unload_ENR005.py ──  ({n} fixes applied)`
3. After the confirmation: `Type  next  for Step03_Ins_SSD_TYP.py  ({n} fixes)   or   done  to stop here.`
4. When user types `next` → save NEXT notebook only. Never save two notebooks in one response.
5. After the LAST notebook, output the combined MIGRATION LOG for all notebooks fixed.
Do NOT output any notebook content in the chat — file write replaces the code block entirely.

Assembly order:
1. `# Databricks notebook source`
2. Cell 0: `%md` purpose summary (enriched with ds_job_name from script if available)
3. Cell 1: `%md` "1 — Setup & Imports" header
4. Cell 2: unified imports
5. Cell 3: `%md` "2 — Parameters & Configuration" header
6. Cell 4: unified parameters (widget defaultValues from script profile if available)
7. Cell 5: `%md` "3 — Table Validation" header
8. Cell 6: table existence checks for every source and target
   - Include only tables that will exist at runtime (external sources + final targets)
   - For every intermediate table eliminated by this merge: omit its check and add:
     `# Intermediate table {name} eliminated — direct DataFrame handoff, check skipped`
   - One check per table variable, no exceptions for tables that remain
   - Use RuntimeError, not assert (assert is suppressed by Python -O flag and gives poor job failure messages):
     ```python
     if not spark.catalog.tableExists(source_table):
         raise RuntimeError(f"[PIPELINE ABORT] Source table not found: {source_table}. Check widget defaultValues and Unity Catalog permissions.")
     ```

If script type is PRE-PROCESSING and data_logic items exist:
9. Cell 7: `%md` "4 — Pre-processing & Data Cleaning" header
         `_Cleaning logic from {script_name}.ksh — applied before source read_`
10. Cell 8+: one cell per data_logic item with traceability block:
    ```python
    # COMMAND ----------
    # Source file  : {script_name}.ksh
    # Logic type   : PRE-PROCESSING
    # Shell cmd    : {original shell command}
    {converted PySpark code}
    # REVIEW: {what engineer must verify}
    ```
Then stage cells from notebooks in DAG order.

If script type is POST-PROCESSING:
- Inject data_logic cells AFTER last target write cell
- Add section header: `## N — Post-processing`
- Same traceability block format as above

If script type is ORCHESTRATION:
- No extra cells injected — only widget defaultValues enriched

For each approved merge group — eliminate intermediate tables:
- Remove write cell from upstream notebook
- Remove read cell from downstream notebook
- Connect DataFrames directly
- Add `# Intermediate table {name} eliminated — direct DataFrame handoff`
- Add `# REVIEW: {table_name} no longer written — verify no external consumers`

For notebooks kept separate — include their cells with origin separator:
```
# ══════════════════════════════════════════════════
# FROM: {original_notebook_filename}
# ══════════════════════════════════════════════════
```

Apply standardizer fixes inline during assembly (not as a second pass):
- I000: canonicalize imports
- G/EXPR: DataStage syntax → PySpark (includes G-NULL-GUARD for F.expr null+empty guard pattern)
- Q: SQL context fixes
- R: source/target conversion
- N: naming standards
- I002: collapse passthrough DataFrames
- L: logic fixes (aggregations, PIVOT, MISSING_HANDLER, CDC, FUNNEL, REMOVE_DUPLICATES)
- S: structural fixes (SparkSession.builder, __main__, mkdirs, display() removal)
- SEC: security fixes (hardcoded credentials → clear value + dbutils.secrets stub)

**count() REVIEW:** Every `print(f"[{stage}] count={df.count()}")` line emitted in source/target
cells must include: `# REVIEW: .count() triggers a full scan — remove for large tables`

## Step 6 — Output

```
MERGE SUMMARY
─────────────────────────────────────────
Merged    : {n} groups — {filenames}
Kept      : {filenames}
Eliminated: {n} intermediate tables
Fixes     : {n} applied (AUTO: {n}  REVIEW: {n})

MIGRATION LOG
─────────────────────────────────────────
Date              : {today YYYY-MM-DD}
Fix rules version : fix-rules-embedded.md (sync: 2026-04-14)
Notebooks in      : {list all input notebooks}
Script analyzed   : {script_name}.ksh | none
Merges executed   : {MERGE-01: Step01 + Step03 → Step01_03_domain.py | none}
Tables corrected  : {expected_path → suggestion_path | none}
Tables flagged    : {n} — search # REVIEW in output
Fixes AUTO        : {list fix IDs}
Fixes REVIEW      : {list fix IDs — require engineer verification before running}
Fixes skipped     : {list fix IDs | none}
─────────────────────────────────────────
```

**Response size guard — never output the merged notebook in the same response as the MERGE SUMMARY or MIGRATION LOG.**

After the MIGRATION LOG block, end Response 1 with:
```
Type  next  to save the merged notebook.
```

Response 2 (after user types `next`): use the Write tool to save the merged notebook to `./fixed/{merged_filename}` (always relative to CWD — create the `fixed/` folder if it does not exist). Then output:
```
Saved: ./fixed/{merged_filename}
```
Then the REVIEW checklist. Do NOT output the notebook content in the chat. Do NOT repeat the MERGE SUMMARY or MIGRATION LOG.

---

## References

`references/analysis-rules.md` — load in Steps 1–3.
Filename patterns, source/target extraction, merge signal scoring,
redundancy detection, DAG logic, consolidation decision rules.

`references/script-analysis-rules.md` — load in Step 0 only (when script detected).
Script classification, extraction rules, shell→PySpark conversion map,
notebook mapping algorithm, discard list, report format.

`references/fix-rules-embedded.md` — load in Step 5 only.
Complete standalone copy of fix-rules.md + stage-patterns.md + expression-map.md.
Used when the datastage-notebook-standardizer skill is not installed (merge path + bare fix all fallback).
